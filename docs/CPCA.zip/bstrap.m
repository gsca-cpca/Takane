function bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,n,m,p,...
            nd,ibt,ics,mg,mh,ia,id,iz,ig)
%bootstrap
global lblv am fm
    ZZ=Z;
    if ia==2 | ia==6 | ia==8, 
        if mg==0,
            ZZt=Jg*(Jg'*ZZ);
        else
            ZZt=pinv(Ksqr)*Jg*(Jg'*Ksqr*ZZ);    
        end%ig mg=0
    end%if ia
    if ia==3 | ia==7 | ia==9,
        if mg==0,
            ZZt=Jgt*(Jgt'*ZZ);
        else
            ZZt=pinv(Ksqr)*Jgt*(Jgt'*Ksqr*ZZ);
        end%if mg=0
    end%if ia
    AM=zeros(m,nd);
    FM=zeros(n,nd);
    AS=AM;
    FS=FM;
    vca=zeros(m,3);
    vcf=zeros(n,3);
    if id==0,
    if mg==1,
        kr=diag(Ksqr);
        Ks=zeros(n,n);
    end%if mg
    Ls=Lsqr;
    L2=L;
    Jhh=Jh;
    Jhht=Jht;
    else%if id=1
        if mg==0,
            N=n;
        else
            N=sum(diag(K));
        end%mg
        p1=diag(K)/N;
        p2(1)=p1(1)
        for j=2:n
            p2(j)=p2(j-1)+p1(j);
        end%j
        g=G;
        z=ZZ;
        sqrn=sqrt(N);
    end%if id
    %
    for k=1:ibt
    if id==0,
    idx=floor(rand(n,1)*n)+1;
    for j=1:n
    z(j,:)=ZZ(idx(j),:);
    if p>0,
        g(j,:)=G(idx(j),:);
    end
    if mg==1,
        Ks(j,j)=kr(idx(j));
    end%mg=1
    end%j
    if ia==2 | ia==6 | ia==8,
        if mg==0,
            Kgg=g;
        else
            Kgg=Ks*g;
        end%if mg
        Jgg=orth(Kgg);
    end%ia=2, 6, or 8
    if ia==3 | ia==7 | ia==9,
        if iz==1 & ig==1,
        if mg==0,
            Kgg=[g,ones(n,1)];
        else
            Kgg=Ks*[g,ones(n,1)];
        end%if mg
        else    
        if mg==0,
            Kgg=g;
        else
            Kgg=Ks*g;
        end%if mg
        end%if iz=1 & ig=1
        Jggt=null(Kgg');
    end%ia=3, 7, or 9
    else%if id=1
        kr=zeros(n,1);
        for j=1:N
           rn=rand(1,1);
           idd=1;              
           while rn>p2(idd) & idd<n+1,
           idd=idd+1;
           end%while
           kr(idd)=kr(idd)+1;
        end%j
        K2=diag(kr);
        Ks=sqrt(K2);
        if ia==2 | ia==6 | ia==8, Jgg=orth(Ks*G); end
        if ia==3 | ia==7 | ia==9, Jggt=null([G,ons(n,1)]'*Ks); end
        lr=sum(K2*Zraw);
        L2=diag(lr);
        Ls=sqrt(L2);
        if ia==4 | ia==6 | ia==7, Jhh=orth(Ls*H); end
        if ia==5 | ia==8 | ia==9, jhht=null([H,ones(m,1)]'*Ls); end
    end%if id
    %
    %    
    if ia==1 | ia==4 | ia==5,
    if ia==1,
    if mg==0,
        zz=z*Ls;
    else
        zz=Ks*z*Ls;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZ*L2*aa*inv(aa'*L2*aa);
    elseif ia==4,
    if mg==0,
        zz=z*Ls*Jhh;
    else
        zz=Ks*z*Ls*Jhh;
    end%mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    if mg==0,
        f=ZZ*L2*aa*inv(aa'*L2*aa);
    else
        f=pinv(Ksqr)*ZZ*L2*aa*inv(aa'*L2*aa);
    end%if mg
    else%ia=5
    if mg==0,
        zz=z*Ls*Jhht;
    else
        zz=Ks*z*Ls*Jhht;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    if mg==0,
        f=ZZ*L2*aa*inv(aa'*L2*aa);
    else
        f=pinv(Ksqr)*ZZ*L2*aa*inv(aa'*L2*aa);
    end%if mg
    end%ia=5
    end%if ia=1, 4, or 5
    %
    if ia==2 | ia==6 | ia==8,
    if ia==2,
    if mg==0,
        zz=Jgg'*z*Ls;
    else
        zz=Jgg'*Ks*z*Ls;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    elseif ia==6,
    if mg==0,
        zz=Jgg'*z*Ls*Jhh;
    else
        zz=Jgg'*Ks*z*Ls*Jhh;
    end%mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    else%ia=8
    if mg==0,
        zz=Jgg'*z*Ls*Jhht;
    else
        zz=Jgg'*Ks*z*Ls*Jhht;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    end%ia=8
    end%ia=2, 6, or 8
    %
    if ia==3 | ia==7 | ia==9,
    if ia==3,
    if mg==0,
        zz=Jggt'*z*Lsqr;
    else
        zz=Jggt'*Ks*z*Ls;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    elseif ia==7,
    if mg==0,
        zz=Jggt'*z*Ls*Jhh;
    else
        zz=Jggt'*Ks*z*Ls*Jhh;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    else%ia=9
    if mg==0,
        zz=Jggt'*z*Ls*Jhht;
    else
        zz=Jggt'*Ks*z*Ls*Jhht;
    end%if mg
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=ZZt*L2*aa*inv(aa'*L2*aa);
    end%ia=9
    end%ia=3, 7, or 9       
    %        
    AM=AM+aa;
    AS=AS+aa.*aa;
    FM=FM+f;
    FS=FS+f.*f;
    if nd==2,
        vca(:,2)=vca(:,2)+aa(:,1).*aa(:,2);
        vcf(:,2)=vcf(:,2)+f(:,1).*f(:,2);
    end%if nd
    end%k
    AM=AM/ibt;
    AS=AS/ibt-AM.*AM;
    FM=FM/ibt;
    FS=FS/ibt-FM.*FM;
    if nd==2,
        vca(:,1)=AS(:,1);
        vca(:,3)=AS(:,2);
        vca(:,2)=vca(:,2)/ibt-AM(:,1).*AM(:,2);
        vcf(:,1)=FS(:,1);
        vcf(:,3)=FS(:,2);
        vcf(:,2)=vcf(:,2)/ibt-FM(:,1).*FM(:,2);
    end%if nd=2
    AS=sqrt(AS);
    FS=sqrt(FS);
    fprintf('Bootstrap mean component loadings and their std\n')
    [AM AS]
    fprintf('Bootstrap mean component scores and their std\n')
    [FM FS]
    if nd==2,
        figure(21)
        text(A(:,1),A(:,2),lblv(1:m,:))
        axis('square')
        am1=am*1.2;
        axis([-am1,am1,-am1,am1])
        xlabel('Component 1')
        ylabel('Component 2')
        title('95% Confidence Regions for Component Loadings') 
        hold on
        for i=1:m
            dm=cellip(vca(i,:),AM(i,:));
        end
        hold off
%        
        if ics==1
        figure(22)
        plot(F(:,1),F(:,2),'.')
        axis('square')
        fm1=fm*1.2;
        axis([-fm1,fm1,-fm1,fm1])
        xlabel('Component 1')
        ylabel('Component 2')
        title('95% Confidence Regions for Component Scores') 
        hold on
        if n<101,
            text(F(:,1),F(:,2),lblv(1:n,:))
        end
        for i=1:n
            dm=cellip(vcf(i,:),FM(i,:));
        end
        hold off
        end%ics
    end%if nd=2
bt=1;
