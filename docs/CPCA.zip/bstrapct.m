function bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N)
%bootstrap
global lblv am fm
    AM=zeros(m,nd);
    FM=zeros(n,nd);
    AS=AM;
    FS=FM;
    vca=zeros(m,3);
    vcf=zeros(n,3);
    nm=n*m;
    p1=reshape(Zraw,nm,1);
    p2(1)=p1(1);
    for j=2:nm
        p2(j)=p2(j-1)+p1(j);
    end%j
    %
    for k=1:ibt
        zt=zeros(nm,1);
        for j=1:N
            rn=rand(1,1);
            idd=1;
            while rn>p2(idd) & idd<nm+1,
                idd=idd+1;
            end%while
            zt(idd)=zt(idd)+1;
        end%j
        Z=reshape(zt,n,m)/N;
        K2=diag(sum(Z'));
        Ks=sqrt(K2);
        L2=diag(sum(Z));
        Ls=sqrt(L2);
        z=pinv(K2)*Z*pinv(L2)-ones(n,m);
        %
        if p>0,
        g=Graw-ones(n,n)*K*Graw/sum(sum(K)');
        D=inv(sqrt(diag(diag(g'*K*g/n))));
        G=g*D;
        end%if p>0    
        if ia==2 | ia==6 | ia==8, Jgg=orth(Ks*G); end
        if ia==3 | ia==7 | ia==9, Jggt=null([G,ones(n,1)]'*Ks); end
        if q>0,
        h=Hraw-ones(m,m)*L*Hraw/sum(sum(L)');
        D=inv(sqrt(diag(diag(h'*L*h/m))));
        H=h*D;
        end%if q>0
        if ia==4 | ia==6 | ia==7, Jhh=orth(Ls*H); end
        if ia==5 | ia==8 | ia==9, jhht=null([H,ones(m,1)]'*Ls); end
    %  
    if ia==1 | ia==4 | ia==5,
    if ia==1,
    zz=Ks*z*Ls;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*u(:,1:nd)*t;
    elseif ia==4,
    zz=Ks*z*Ls*Jhh;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*u(:,1:nd)*t;
    else%ia=5
    zz=Ks*z*Ls*Jhht;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*u(:,1:nd)*t;
    end%ia=5
    end%if ia=1, 4, or 5
    %
    if ia==2 | ia==6 | ia==8,
    if ia==2,
    zz=Jgg'*Ks*z*Ls;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jgg*u(:,1:nd)*t;
    elseif ia==6,
    zz=Jgg'*Ks*z*Ls*Jhh;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jgg*u(:,1:nd)*t;
    else%ia=8
    zz=Jgg'*Ks*z*Ls*Jhht;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jgg*u(:,1:nd)*t;
    end%ia=8
    end%ia=2, 6, or 8
    %
    if ia==3 | ia==7 | ia==9,
    if ia==3,
    zz=Jggt'*Ks*z*Ls;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jggt*u(:,1:nd)*t;
    elseif ia==7,
    zz=Jggt'*Ks*z*Ls*Jhh;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhh*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jggt*u(:,1:nd)*t;
    else%ia=9
    zz=Jggt'*Ks*z*Ls*Jhht;
    [u,d,v]=svd(zz,0);
    a=pinv(Ls)*Jhht*v(:,1:nd)*d(1:nd,1:nd);
    atA=a'*A;
    [u0,d0,v0]=svd(atA);
    t=u0*v0';
    aa=a*t;
    f=pinv(Ks)*Jggt*u(:,1:nd)*t;
    end%ia=9
    end%ia=3, 7, or 9       
    %        
    AM=AM+aa;
    AS=AS+aa.*aa;
    FM=FM+f;
    FS=FS+f.*f;
    if nd==2,
        vca(:,2)=vca(:,2)+aa(:,1).*aa(:,2);
        vcf(:,2)=vcf(:,2)+f(:,1).*f(:,2);
    end%if nd
    end%k
    AM=AM/ibt;
    AS=AS/ibt-AM.*AM;
    FM=FM/ibt;
    FS=FS/ibt-FM.*FM;
    if nd==2,
        vca(:,1)=AS(:,1);
        vca(:,3)=AS(:,2);
        vca(:,2)=vca(:,2)/ibt-AM(:,1).*AM(:,2);
        vcf(:,1)=FS(:,1);
        vcf(:,3)=FS(:,2);
        vcf(:,2)=vcf(:,2)/ibt-FM(:,1).*FM(:,2);
    end%if nd=2
    AS=sqrt(AS);
    FS=sqrt(FS);
    fprintf('Bootstrap mean component loadings and their std\n')
    [AM AS]
    fprintf('Bootstrap mean component scores and their std\n')
    [FM FS]
    if nd==2,
        figure(21)
        text(A(:,1),A(:,2),lblv(1:m,:))
        axis('square')
        am1=am*1.2;
        axis([-am1,am1,-am1,am1])
        xlabel('Component 1')
        ylabel('Component 2')
        title('95% Confidence Regions for Column Scores') 
        hold on
        for i=1:m
            dm=cellip(vca(i,:),AM(i,:));
        end
        hold off
%        
        if ics==1
        figure(22)
        plot(F(:,1),F(:,2),'.')
        axis('square')
        fm1=fm*1.2;
        axis([-fm1,fm1,-fm1,fm1])
        xlabel('Component 1')
        ylabel('Component 2')
        title('95% Confidence Regions for Row Scores') 
        hold on
        if n<101,
            text(F(:,1),F(:,2),lblv(1:n,:))
        end
        for i=1:n
            dm=cellip(vcf(i,:),FM(i,:));
        end
        hold off
        end%ics
    end%if nd=2
bt=1;
