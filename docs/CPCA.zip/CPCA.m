%CPCA program -- Written by Yoshio Takane
%Copyright 2015 Yoshio Takane. All rights reserved.akane, 2015
%This program allows you to analyze:
%(1) Continuous multivariate data, 
%(2) Item category data (non-unitary frequencies of item-ctgory response 
%patterns may b input as the left-hand side metric), and
%(3) Contingency tables
%by CPCA (Constrained Principal Component Analysis). Tere are 9 possible 
%analyses as described on page 80 of Takane (2013).
%To use the program, you need to have the following files:
%(1) The main data, Z, plus possibly the left-hand side constraint matrix, 
%G. This will be input in the form of [Z, G] or Z alone (if there is no G).
%At least the main data matrix is mandatory. The data matrix Z is an n by m 
%matrix, where typically n is greater than m, and the lefthand side 
%constraint matrix G is an n by p matrix. Inthe main program (around line 
%75), change the file name (mezzich.txt) into an appropriate one. The
%variable name (mezzich) on the following line should also be changed
%accordingly,
%(2) The right-hand side constraint matrix H (optional). If there is an H,
%an m by q matrix will be input. In the main program, change the file name 
%(Hmat.txt) around line 95 into an approprite one. The name "Hmat" in the 
%following statement should also be changed accordingly.
%(3) The left-hand side metric K (optional). This has to be a diagonal 
%matrix. The diagonal elements of this matrix is input as a vector. In the
%main program, change the file name (Gm.txt) in the "load" statement 
%(around line 115) into an appropriate one. The variable "Gm" in the 
%following two statements should also be changed accordingly.
%(4) The right-hand side metric L (optioal). This can be a diagonal or full
%symmetric positive-definite matrix. If it is a diagonal or full pd atrix 
%will be distinguished by variable "mh" to be entered while running the 
%program. When it is diagonal, the diagonal elements are input as a vector. 
%When it is full, and an m by m matrix is input. In either case, change the 
%file name (Hm.txt) into an appropriate one in two "load" statements 
%(around line 129 and 133). The variable "Hm" following the load statements
%should also be changed accordingly.
%(5) The target matrix for Procrustes rotation (optional). When the 
%rotation is requested, an m by nd target matrix has to be suplied in a 
%file. In the "rot.m" routine, change the file name (Ctarget.txt) in the 
%"load" statement (line 44) into an appropriate name. The bariable 
%"Ctarget" in the following statement (line 45) should also be changed 
%accordingly, so that the target matrix is stored in variable "C".
%
%You are asked to enter the following values by the program as the analysis
%progresses:
%(1) m: The number of variables in Z.
%(2) q: The number of constraints in the right-hand side constraint matrix
%H. 
%(3) id: The data type (1=continuous data, 2=item-category data,
%3=contingency table).
%(4) mg: 1=diagonal left-hand side metric. 
%(5) mh: 1=diagonal right-hand side metric, 2=full symmetric positive-
%definite matrix.
%(6) iz: 0=raw data, 1=columnwise standarize, 2=rowwise standardize.
%(7) ig: 0=raw G, 1=columnwise standardize G, 2=columnwise center G.
%(8) ih: H=raw H, 1=columnwise standardize H, 2=columnwise center H.
%(9) ia: The type of analysis: 1=Z, 2=P_{G/K}Z, 3=Q_{G/K}Z, 4=ZP_{H/L}', 
%5=ZQ_{H/L}', 6=P_{G/K}ZP_{H/L}', 7=Q_{G/K}ZP_{H/L}', 8=P_{G/K}ZQ_{H/L}',
%9=Q_{G/K}ZQ_{H/L}'.
%(10) nd: The number of componnts (0<nd<6).
%(11) ir: Rotation (0=no rotation, 1=varimax rotation, 2=promax rotation, 
%3=Procrustes rotation).  
%(12) ics: 1=component scores are printed (and plotted, if nd>1).
%(13) ibt: The bootstrap sample size (0=no bootstrap).
%
global lblv am fm
lblv=['1 ';'2 ';'3 ';'4 ';'5 ';'6 ';'7 ';'8 ';'9 ';'10';...
          '11';'12';'13';'14';'15';'16';'17';'18';'19';'20';...
          '21';'22';'24';'24';'25';'26';'27';'28';'29';'30';...
          '31';'32';'33';'34';'35';'36';'37';'38';'39';'40';...
          '41';'42';'43';'44';'45';'46';'47';'48';'49';'50';...
          '51';'52';'53';'54';'55';'56';'57';'58';'59';'60';...
          '61';'62';'63';'64';'65';'66';'67';'68';'69';'70';...
          '71';'72';'73';'74';'75';'76';'77';'78';'79';'80';...
          '81';'82';'83';'84';'85';'86';'87';'88';'89';'90';...
          '91';'92';'93';'94';'95';'96';'97';'98';'99';'00'];
load mezzichZG.txt
Y=mezzichZG;
[n mp]=size(Y);
sqrn=sqrt(n);
%n: The number of rows in Z 
m=input('\nEnter the number of variables (m) in Z: ');
%m: The number of columns in Z
p=mp-m;
%p: The number of columns in G
Zraw=Y(:,1:m);
Graw=Y(:,m+1:mp);
q=input('\nEnter the number of columns (q) in H: ');
%q: The number of columns in H
%Obtain H, if q>0
if q>0
    load mezzichH.txt
    Hraw=mezzichH;
end
%Data type:id (0=continuous data, 1=multiple choice data, 2=contingency table)
fprintf('\nEnter 0 if the data are continuous (default).\n')
fprintf('Enter 1 if the data are multiple-choice.\n')
fprintf('Enter 2 if the data are a contingency table.\n\n')
id=input('Enter 0, 1, or 2 (for the vaue of id): ');
if id==0, %continuous data    
%metric matrix for rows
fprintf('\nEnter 0 if the row-side metric (K) is identity (default).\n')
fprintf('Enter 1 if K is diagonal and to be uploaded.\n\n')
mg=input('Enter 0, or 1 (for the value of mg): ');
if mg==0 %identity metric for rows
    K=eye(n);
    Ksqr=K;
else mg==1 %diagonal metric for rows
    load Gm.txt
    K=diag(Gm);;
    Ksqr=diag(sqrt(Gm));
end%mg
%metric matrix for columns
fprintf('\nEnter 0 if the column-side metric (H) is identity (default).\n')
fprintf('Enter 1 if L is diagonal and to be uploaded.\n')
fprintf('Enter 2 if L is a full pd and to be uploaded.\n\n')
mh=input('Enter 0, 1, or 2 (for the value of mh): ');
if mh==0 %identity metric for columns
    L=eye(m);
    Lsqr=L;
elseif mh==1 %diagonal metric for columns
    load Hm.txt
    L=diag(Hm);;
    Lsqr=diag(sqrt(Hm));
else %a full pd metric matrix for columns
    load Hm.txt
    L=Hm;
    [u,d,v]=svd(L);
    Lsqr=u*sqrt(d)*v';
end%mh
fprintf('\nEnter 0 if raw data are analyzed (default).\n')
fprintf('Enter 1 if columnwise standardized data are analyzed.\n')
fprintf('Enter 2 if rowwise standardized data are anaalyzed.\n\n')
iz=input('Enter 0, 1, or 2 (for the value of iz): ');
%data preprocessing
if iz==0, %raw data
    Z=Zraw;
elseif iz==1, %columnwise standardize the data
    z=Zraw-ones(n,n)*K*Zraw/sum(sum(K)');
    D=inv(sqrt(diag(diag(z'*z/n))));
    Z=D*z;
else %rowwise standardize the data
    z=Zraw-Zraw*L*ones(m,m)/sum(sum(L)');
    D=inv(sqrt(diag(diag(z*z'/m))));
    Z=D*z;
end
sst=trace(Z'*K*Z*L);%total SS
%    
elseif id==1, %multiple-choice data
%construct a dummy variable matrix from subject
%by item data
Z=Zraw;
cn=max(Z);
cnt=sum(cn);
Zraw=zeros(n,cnt);
cc=0;    
for j=1:m
for i=1:n
    Zraw(i,cc+Z(i,j))=1;
end%i
    cc=cc+cn(j);
end%j
m=cnt;
%metric matrix for rows
fprintf('\nEnter 0 if the row-side metric (K) is identity (default).\n')
fprintf('Enter 1 if K is diagonal and to be uploaded.\n\n')
mg=input('Enter 0, or 1 (for the value of mg): ');
if mg==0,
    K=eye(n,n);
    Ksqr=K;
else
    load Gm.txt
    K=diag(Gm);
    Ksqr=sqrt(K);
end%mg
mh=1;
L=diag(sum(Zraw));
Lsqr=sqrt(L);
Z=Zraw-ones(n,n)*K*Zraw/sum(sum(K)');
mg=1;
mh=1;
sst=trace(Z'*K*Z*L);%total SS
%
else%id=2, contingency table
K=diag(sum(Zraw'));
L=diag(sum(Zraw));
mg=1;
mh=1;
N=sum(sum(Zraw)');
sqrn=sqrt(N);
K=K/N;
Ksqr=sqrt(K);
L=L/N;
Lsqr=sqrt(L);
Zraw=Zraw/N;
Z=inv(K)*Zraw*inv(L)-ones(n,m);
sst=trace(Z'*K*Z*L);%total SS
if q>0, ih=2; end
end%if id
%
%G preprocessing
if p==0,
    ig=0;
    G=eye(n);
else    
ig=1;
fprintf('\nEnter 0 if raw G is used (default).\n')
fprintf('Enter 1 if G is standardized.\n')
fprintf('Enter 2 if G is normalized (w/o centering.\n\n')
ig=input('Enter 0, 1, or 2 (for the value of ig): ');
if id==2 & p>0, ig=1; end
if ig==0, %raw G
    G=Graw;
elseif ig==1 %columnwise standardize G
    g=Graw-ones(n,n)*K*Graw/sum(sum(K)');
    D=inv(sqrt(diag(diag(g'*K*g/n))));
    G=g*D;
else% columnwise normalize G
    g=Graw;
    D=inv(sqrt(diag(diag(g'*K*g/n))));
    G=g*D;
end%if ig
end%if p=0
Jg=orth(Ksqr*G);
Jgt=null(Jg');
%H preprocessing
if q==0,
ih=0;
H=eye(m);
else
fprintf('\nEnter 0 if raw H is used (default).\n')
fprintf('Enter 1 if H is standardized.\n')
fprintf('Enter 2 if H is only normalized (w/o centering).\n\n')
ih=input('Enter 0, 1, or 2 (for the value of ih): ');
if id==2 & q>0, ih=1; end
if ih==0, %raw H
    H=Hraw;
elseif ih==1, %columnwise standardize H
    h=Hraw-ones(m,m)*L*Hraw/sum(sum(L)');
    D=inv(sqrt(diag(diag(h'*L*h/m))));
    H=h*D;
else%if ih=2, columnwise normalize H
    D=inv(sqrt(diag(diag(Hraw'*L*Hraw/m))));
    H=Hraw*D;    
end%if ih
end%if q=0
Jh=orth(Lsqr*H);
Jht=null(Jh');
%
%Analysis 1: Z
%         2: P_{G/K}Z
%         3: Q_{G/K}Z
%         4: ZP_{H/L}'
%         5: ZQ_{H/L}'
%         6: P_{G/K}ZP_{H/L}'
%         7: Q_{G/K}ZP_{H/L}'
%         8: P_{G/K}ZQ_{H/L}'
%         9: Q_{G/K}ZQ_{H/L}'
ia=1;
ia=input('\nChoose an analysis from the list of nine: ');
if ia==1, fprintf('\nMatrix Z is analyzed.\n\n'), end
if ia==2, fprintf('\nMatrix P_{G/K}Z is analyzed.\n'), end
if ia==3, fprintf('\nMatrix Q_{G/K}Z is analyzed.\n'), end
if ia==4, fprintf('\nMatrix ZP_{H/L}^{t} is analyzed.\n'), end
if ia==5, fprintf('\nMatrix ZQ_{H/L}^{t} is analyzed.\n'), end
if ia==6, fprintf('\nMatrix P_{G/K}ZP_{H/L}^{t} is analyzed.\n'), end
if ia==7, fprintf('\nMatrix Q_{G/K}ZP_{H/L}^{t} is analyzed.\n'), end
if ia==8, fprintf('\nMatrix P_{G/K}ZQ_{H/L}^{t} is analyzed.\n'), end
if ia==9, fprintf('\nMatrix Q_{G/K}ZQ_{H/L}^{t} is analyzed.\n'), end
imp=0;
if ia==2 | ia==3,
    if p==0,
        fprintf('There must be a G matrix.')
        imp=1;
        break
    end
end
if ia==4 | ia==5,
    if q==0,
        fprintf('There must be an H matrix.')
        imp=1;
        break
    end
end
if ia>5,
    if p==0 | q==0
        fprintf('There must be both a G matrix and an H matrix.')
        imp=1;
        break
    end
end
%
if imp==0,
    nd=2;
    nd=input('\nEnter the number of components (nd): ');
    if nd>5,
        nd=5;
        fprintf('The maximum number of components is 5.\n\n') 
    end
    ir=0;
    fprintf('\nEnter 0 if no rotation is required (default).\n')
    fprintf('Enter 1 if varimax rotation is desired.\n')
    fprintf('Enter 2 if promax rotation is desired.\n')
    fprintf('Enter 3 if Procrustes rotation is desired.\n\n')
    ir=input('Enter 0, 1, 2, or 3 (ir): ');
    if id==2,
        fprintf('\nNo rotation is applied for contingency table data,\n') 
        ir=0;
    end
    if nd==1,
        ir=0;
        fprintf('\nNo rotation is feasible for nd = 1.\n\n')
    end
    ics=0;
    if id==2, ics=1; end
    ics=input('\nEnter 1 if component scores are desired (ics): ');
    ibt=0;
    fprintf('\nEnter the bootstrap sample size (ibt)\n')
    ibt=input('if standard errors are desired: ');
    %
if ia==2 | ia==6 | ia==8, Jg=orth(Ksqr*G); end
if ia==4 | ia==6 | ia==7, Jh=orth(Lsqr*H); end
if (iz==1 & ig==1) | id==2, 
    if ia==3 | ia==7 | ia==9, 
        Jgt=null([G,ones(n,1)]'*Ksqr);
    end%if ia
elseif (iz==2 & ih==1) | id==2,
    if ia==5 | ia==8 | ia==9,
        Jht=null([H,ones(m,1)]'*Lsqr);
    end
else
    if ia==3 | ia==7 | ia==9,
        Jgt=null(G'*Ksqr);
    end%if ia
    if ia==5 | ia==8 | ia==9,
        Jht=null(H'*Lsqr);
    end%if ia
end
    %    
if ia==1,
    B=Ksqr*Z*Lsqr;
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,sst,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,sst,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,sst,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);    
    end%if ibt>0
    end%if id
end%if ia=1
%
if ia==2,
    B=Jg'*Ksqr*Z*Lsqr;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,  
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id
    end% if ia=2
%    
if ia==3,
    B=Jgt'*Ksqr*Z*Lsqr;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
%rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
%bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);   
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id
end%if ia=3
%
if ia==4,
    B=Ksqr*Z*Lsqr*Jh;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id<2
end%if ia=4
%
if ia==5,
    B=Ksqr*Z*Lsqr*Jht;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>2
    end%if id<2
end%if ia=5
%
if ia==6,
    B=Jg'*Ksqr*Z*Lsqr*Jh;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2
    F=sqrn*pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id<2
end%if ia=6
%
if ia==7,
    B=Jgt'*Ksqr*Z*Lsqr*Jh;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*Jh*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id<2
end%if ia=7
%
if ia==8,
    B=Jg'*Ksqr*Z*Lsqr*Jht;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jg*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>2
    end%if id<2
    end%if ia=8
%
if ia==9,
    B=Jgt'*Ksqr*Z*Lsqr*Jht;
    ssr=trace(B'*B);%regression SS
    ppct=pct(ssr,sst);
    [u,d,v]=svd(B,0);
    dd=diag(d(1:nd,1:nd));
    dd=dd.*dd;
    if id<2,
    F=sqrn*pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd)/sqrn;
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    %rotation
    if ir>0, 
        ro=rot(A,F,ssr,n,m,nd,ir,ics,id);
    end%if ir
    %bootstrap    
    if ibt>0,
        bt=bstrap(Z,Zraw,K,L,Ksqr,Lsqr,G,A,F,Jg,Jgt,Jh,Jht,sqrn,...
            n,m,p,nd,ibt,ics,mg,mh,ia,id,iz,ig);
    end%if ibt
    else%if id=2
    F=pinv(Ksqr)*Jgt*u(:,1:nd);
    A=pinv(Lsqr)*Jht*v(:,1:nd)*d(1:nd,1:nd);
    rl=prpl(A,F,dd,ssr,n,m,nd,ics,0,id);
    if ibt>0,
        bt=bstrapct(Z,Zraw,K,L,Ksqr,Lsqr,Graw,Hraw,A,F,...
            Jg,Jgt,Jh,Jht,sqrn,n,m,p,q,nd,ibt,ics,mg,mh,ia,id,N);
    end%if ibt>0
    end%if id<2
end%if ia=9
end%if imp
