function pt=pct(ssr,sst)
pt=100*ssr/sst;
fprintf('\nPercent SS explained by External Analysis: %12.4f\n\n',pt)
