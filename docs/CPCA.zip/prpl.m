function rl=prpl(A,F,dd,sst,n,m,nd,ics,fign,id)
%print/plot
    global lblv am fm
    d1=(100/sst)*dd;
    d2=zeros(nd,1);
    d2(1)=d1(1);
    if nd>1,
        for j=2:nd
            d2(j)=d2(j-1)+d1(j);
        end%j
    end%if nd
    fprintf('Sum of Squares (SS): %12.4f\n\n',sst)
    fprintf('Componentwise SS')
    dd'
    fprintf('Percent SS')
    d1'
    fprintf('Cummulative Percent SS')
    d2'
    fprintf('Component Loadings\n')
    A
    %plot A
    if nd>1,
    am=max(max(abs(A)))*1.2;
    nf=0;
    for j=1:nd-1
        for i=j+1:nd
            nf=nf+1;
            figure(fign*10+nf)
            text(A(:,j),A(:,i),lblv(1:m,:))
            axis('square')
            axis([-am am -am am])
            xlabel(['Component ',int2str(j)])
            ylabel(['Component ',int2str(i)])
            if id<2,            
                title('Plot of Component Loadings')
            else
                title('Plot of Column Scores')
            end%if id
            hold on
            text(0,0,'+')
            hold off
        end%i
    end%j
    end%if nd
    if ics==1
        fprintf('Component Scores')
        F
    if nd>1,
    fm=max(max(abs(F)))*1.2;
    for j=1:nd-1
        for i=j+1:nd
            nf=nf+1;
            figure(fign*10+nf)
            plot(F(:,j),F(:,i),'.')
            axis('square')
            axis([-fm fm -fm fm])
            xlabel(['Component ',int2str(j)])
            ylabel(['Component ',int2str(i)])
            if id<2,
                title('Plot of Component Scores')
            else
                title('Plot of Row Scores')
            end%if id
            hold on
            text(0,0,'+')
            if n<101,
            text(F(:,j),F(:,i),lblv(1:n,:))
            end
            hold off
        end%i
    end%j
    end%if nd
    end%if ics
rl=1;