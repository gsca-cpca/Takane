function rt=rot(A,F,sst,n,m,nd,ir,ics,id)   
if ir==1,
        %varimax rotation
        fprintf('Varimax rotation\n')
        T=varmx(A);
        Av=A*T;
        Fv=F*T;
        ddv=n*diag(Av'*Av);
        rl=prpl(Av,Fv,ddv,sst,n,m,nd,ics,1,id);
elseif ir==2,
        %promax rotation
        fprintf('Promax rotation\n')
        T=varmx(A);
        Av=A*T;
        cm=inv(sqrt(diag(diag(Av*Av'))));
        Av1=cm*Av;
        Av2=Av1.*abs(Av1).^3;
        bm=inv(diag(max(abs(Av2))));
        C=Av2*bm;
        D=eye(nd);
        iter=0;
        dif=1;
        f0=1000;
        CD=C*D;
        while iter<100 & dif>.00001
        iter=iter+1;
        [u d v]=svd(Av'*CD);
        T=u*v';
        Av1=Av*T;
        D=inv(diag(diag(C'*C)))*diag(diag(C'*Av1));
        CD=C*D;
        E=CD-Av1;
        fn=trace(E'*E);
        dif=f0-fn;
%        [iter dif fn f0]
        f0=fn;
        end%while
        Av=Av1;
        ddv=n*diag(Av'*Av);
        Fv=F*T;
        rl=prpl(Av,Fv,ddv,sst,n,m,nd,ics,1,id);
else
        %Procrustes rotation
        load Ctarget.txt
        C=Ctarget;
        [u d v]=svd(A'*C);
        T=uv';
        Av=A*T;
        ddv=n*diag(Av'*Av);
        Fv=F*T;
        rl=prpl(Av,Fv,ddv,sst,n,m,nd,ics,1,id);
end
rt=1;
