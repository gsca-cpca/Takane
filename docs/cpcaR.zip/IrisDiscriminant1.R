#CANO reduces to canonical discriminant analysis(CDA) when one of two sets
#of variables consists of dummy-coded categorical variables. This program
#applied CDA to the Fishers's (1936) iris data to discriminate among the 
#species.
#
#Read the data file; The fisheriris data consists of 50 samples from each
#of the three species of Iris(setosa, verginica, and versicolor) with four
#features measured from each sample(length, width, sepals, and petals).
iris.data <-read.table("iris.txt")

XX<-iris.data[,1:4]
#n is for 150 samples
n<-150
#Get the columnwise centered matrix X with respect to the means
X <- t(XX)-colMeans(XX)
X <- t(X)
#Build a 150x3 matrix G of dummy variables indicating group memberships of
#cases(subjects)
G1 <- cbind(rep(1,50), rep(0,50), rep(0,50))
G2 <- cbind(rep(0,50), rep(1,50), rep(0,50))
G3 <- cbind(rep(0,50), rep(0,50), rep(1,50))
G <- rbind(G1, G2, G3)
#K is the variance of G
K <-t(G)%*%G
#Ksqi is the square root and inverse of matrix K
Ksqi <-sqrt(solve(K));
#X2 is the variance-covariance of X (multiplied by n)
X2 <-t(X)%*%X
#SVD of X2
d <- diag(svd(X2)$d)
u <- svd(X2)$u
v <- svd(X2)$v
Xsqi <- v%*%sqrt(solve(d))%*%t(u)
A <- Ksqi%*%t(G)%*%X%*%Xsqi
#SVD of A
d1 <- diag(svd(A)$d)
u1 <- svd(A)$u
v1 <- svd(A)$v
#Weight matrix for G
U <- Ksqi%*%u1[,1:2]%*%d1[1:2,1:2]
#Weight matrix for X
V<-Xsqi%*%v1[,1:2]
print('Correlations of species')
diag(t(d1))
#Fisher's result
Uc<- c(-5,1,4,1,-3,2)
dim(Uc)<- c(3,2)
print('Correlation between the result of')
print('discriminant analysis and that of Fisher')
cor(U,Uc)

print('Weights applied to G indications group memberships')
u1[,1:2]
print('Weights for the predictor variables')
v1[,1:2]

#Plot of the result
#Label: square indicate setosa, asterisks indicate versicolor, and circles
#virginia.
lbl <- c('[]','*','o')
Vx<-X%*%V
ie<-0
dev.new()
plot.new()
#Specify Limits of Axes
plot(c(-0.3,0.3), c(-0.3,0.3), type="n",axes="F")
#Draw axes
A<-c(-0.25, 0.25, 0, 0)
dim(A)<-c(2,2)
lines(A, col="blue", lwd=2)
B=c(0, 0, -0.25, 0.25)
dim(B)<-c(2,2)
lines(B, col="blue", lwd=2)
# for each of 3 species, the results are plotted for component 1 (x-axis)
# against 2 (y-axis)
for (i in 1:3){
ib<- ie+1
ie <-ie+50
text(Vx[ib:ie,1],Vx[ib:ie,2],lbl[i],col="red")
}
#Three integers indicate the centroids of the three species(1 setosa; 2 
#versicolor; 3 virginica).
lbc <-c('1','2','3')
text(U[,1],U[,2],lbc)
