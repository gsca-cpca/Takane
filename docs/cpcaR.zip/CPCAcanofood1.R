#CANO
#This program applies canonical correlation analysis (CANO) to Example 2.1.
#CANO extracts a pair of linear combinations of variables, one from each
#set, which are maximally correlated with each other. If one pair is not
#sufficient to capture the majority of the total association between the
#two sets of variables, another pair of canonical variates are extracted.
#This process is continued until no significant association is left
#unaccounted for in the two sets of variables.

#Read the data file; The food contains a 47-case by 6-variable data
#matrix; Four of the six pertain to food variables, andtheremaining 
#two to cancer mortality rates
food.data <- read.table("food.txt")
#Get the dimension of data matrix
dimension <- dim(food.data)
n <- dimension[1]
p <- dimension[2]
#Get the means of the six variable
mX <- colMeans(food.data)
#Get the columnwise centered matrix X with respect to the means
X <- t(food.data)-mX
X <- t(X)
#std is a diagonal matrix of standard deviations in the diagonal
std <- sqrt(diag(t(X)%*%X))
#D is the diagonal matrix of inverse of std
D <- solve(diag(std))
#Z is a matrix of "standardized" data. (The standardization is made 
#in such a way that Z'Z gives the correlation matrix rahter than 
#Z'Z/n
Z <- X%*%D
#p1 is the number of variables in the first set (food variables)
p1 <- 4
#p2 is the number of variables in the second set (cancer variables)
p2 <- 2
#Z1 is the data matrix of the four variables related to foods
Z1 <- Z[,1:4]
#Z2 is the data matrix of the two variables related to cancers
Z2<-Z[,5:6]
#Pz1 is the orthogonal projector onto the food variables
Pz1 <- Z1%*%solve(t(Z1)%*%Z1)%*%t(Z1)
#Pz2 is the orthogonal projector onto the cancer variables
Pz2 <- Z2%*%solve(t(Z2)%*%Z2)%*%t(Z2)
A<-Pz1%*%Pz2
#SVD of A
d <- diag(svd(A)$d)
u <- svd(A)$u
v <- svd(A)$v
#Extract the first two columns for weight X 
U <- u[,1:2]
#Extract the first two columns for weight Y
V <- v[,1:2]
print('Weights on food variables (X)')
Us <- solve(t(Z1)%*%Z1)%*%t(Z1)%*%U
Us
print('Weight on cancer variables (Y)')
Vs <- solve(t(Z2)%*%Z2)%*%t(Z2)%*%V
Vs

print('Correlations between the canonical variates')
print('and the four food variables')
t(Z1)%*%U
print('Correlations between the canonical variates')
print('and the two cancer variables')
t(Z2)%*%V

#Extract correlations from the singular value 
D<- d[1:2,1:2]
print('Canonical correlation')
diag(t(D))
print('Squared of canonical correlation')
diag(t(D))*diag(t(D))
print('Total association')
sum(diag(D^2))
print('Total association')
sum(diag(Pz1%*%Pz2))
