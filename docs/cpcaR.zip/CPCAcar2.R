#This program first fits a special case of CPCA called correspondence
#analysis(CA), also known as dual scaling(DS) to analyze the cross
#classification table(in finding out which size classes of cars are more
#and less popular among which age and income groups). Then fits to
#canonical corrspondence analysis(CCA), which is also a special case of CA.
#(The constrained CA is done by incorporate the information on age and 
#income in the representation of the rows and the information on size 
#classes in the representation of the columns of the table).
#
#*********Notice that this program needs corpcor library********
#if the package is not installed, enter:
# >install.packages("corpcor") 
#
#Read the data file The car's data contains a cross-tabulation of cars 
#purchased in terms of class size of the car (classified into 14 class
#sizes), age (classified into 7 groups) and income of purchasers 
#(classified into 9 groups).
car.data <- read.table("car.txt")
#Assign the data matrix to F excluding the age and income variable number 
#in the first and second column
F<-car.data[,3:16]
#Get the dimensions of the data matrix
x<- dim(F)
n<-x[1]
p<-x[2]
#Dr is the diagonal matrix with row totals of the table as the diagonal 
#elements
Dr<-diag(rowSums(F))
#invDr is the inverse of Dr
invDr<-solve(Dr)
#sqriDr is the square of invDr
sqriDr<-sqrt(invDr)
#c is the vector of column totals
c<-colSums(F)
#N is the total sample size
N<-sum(c)
#Dc is the diagonal matrix with column totals as the diagonal elements
Dc<-diag(c)
#incDc is the inverse of Dc
invDc<-solve(Dc)
#sqriDc is the square root of InvDc
sqriDc<-sqrt(invDc)
#Z is a "standardized" data matrix (with a trivial component eliminated)
temp<-F-(Dr%*%rep(1,n)%*%t(rep(1,p))%*%Dc)/N
temp<-t(t(temp)) 
Z<-sqriDr%*%temp%*%sqriDc
#SVD of Z (u: the matrix of left signular vectors, d: the diagonal 
#nonzero singular values, v: the matrix of right singular vectors)
d <- diag(svd(Z)$d)
u <- svd(Z)$u
v <- svd(Z)$v
#Assign diagonal elements of d(transposed) to vector dd
dd<-diag(t(d))
print('The total SS')
SST<-t(dd)%*%dd
SST
print('Squared sigunlar values for each dimension')
dde<-dd*dd
dde
print('Percentage of contribution')
dde/SST
#r is the number of components to be retained
r<-2
#The square root of N
sqrN<-sqrt(N)
#Row representaton in principal coordinates
U<-sqrN*sqriDr%*%u[,1:r]%*%d[1:r,1:r]
#Column representation in standard coordinates
V<-sqrN*sqriDc%*%v[,1:r]
#Reflect the second column of V
V[,2]<--V[,2]
#Gitter some points
V[11,1]<-V[11,1]-.05
#Plots of configurations of size of classes of cars(Unconstrained CA)
dev.new()
plot.new()
#Specify Limits of Axes
plot(-2.5:2.5, -2:3, type="n",axes="F")
#Draw axes
Z1<-c(-2.5, 2.5, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -2, 3)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Heading for the plot
title(main = '(a)')
#Define labels for plotting
labc<-c('A','B','C','D','E','F','G','H','I','J','K','L','M','N')
#For each of 14 size classes, component loadings are ploted for 
#Compnents 1 (x-axis) against 2 (y-axis)
for (i in 1:p)
	text(V[i,1],V[i,2],labc[i])

#Row representation
U<-sqrN*sqriDr%*%u[,1:r]%*%d[1:r,1:r]
#Reflect the second column of U
U[,2]<--U[,2]
#Plots of age and income groups of purchasers(Unconstrained CA)
dev.new()
plot.new()
#Specify Limits of Axes
plot(c(-0.7,0.7), c(-0.7,0.7), type="n",axes="F")
#Draw axes
Z1<-c(-0.7, 0.7, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -0.7, 0.7)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Heading for the plot
title(main = '(b)')
#plot points(x,y given) using solid lines
lines(U[1:9,1],U[1:9,2])
lines(U[46:54,1],U[46:54,2])
lines(U[55:63,1],U[55:63,2])
lines(U[1+9*(0:6),1],U[1+9*(0:6),2])
lines(U[9+9*(0:6),1],U[9+9*(0:6),2])

#Build a vector of length 9 containing the value 1 in all position
e<-rep(1,9)
#ii is a 9x9 identity matrix
ii<-diag(9)
#Build a 63x16 of age and income information matrix G1 of dummy variables 
#where the first 7 columns are the 9-component vector of ones, and the 
#last 9 columns are the identity matrix of order 9 with respect to each
#component.
zeros<-rep(0,9)
G11<-cbind(e,zeros,zeros,zeros,zeros,zeros,zeros,ii)
G12<-cbind(zeros,e,zeros,zeros,zeros,zeros,zeros,ii)
G13<-cbind(zeros,zeros,e,zeros,zeros,zeros,zeros,ii)
G14<-cbind(zeros,zeros,zeros,e,zeros,zeros,zeros,ii)
G15<-cbind(zeros,zeros,zeros,zeros,e,zeros,zeros,ii)
G16<-cbind(zeros,zeros,zeros,zeros,zeros,e,zeros,ii)
G17<-cbind(zeros,zeros,zeros,zeros,zeros,zeros,e,ii)
G1<-rbind(G11,G12,G13,G14,G15,G16,G17)

#Build a 14x11 of size classes information matrix H1 of dummy variables
#where the first 6 columns represent the size, and the last 5 columns
#represent the luxuriousness of cars.
H1<-matrix(c(1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
	1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
	0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0,
	0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
	0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0,
	0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0,
	0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0,
	0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0,
	0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0,
	0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
	0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
	0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0), ncol=14, nrow=11)
H1<-t(H1)

Qr<-diag(n)-rep(1,n)%*%t(rep(1,n))%*%Dr/N
#G is the age and income information matrix where the first part represents
#age groups, and the second part income group. 
G<-Qr%*%G1
Qc<-diag(p)-rep(1,p)%*%t(rep(1,p))%*%Dc/N
#H is the size classes information matrix where the first part represent 
#the size, and the second part represent the luxuriousness of cars.
H<-Qc%*%H1
#load corpcor library 
library("corpcor")
#Adjusted Dr accounted for by G using Moore-Penrose pseudoinverse
temp<-t(G)%*%Dr%*%G
MP<-pseudoinverse(temp)
PgDr<-G%*%MP%*%t(G)%*%Dr
#Adjusted Dc accounted for by G using Moore-Penrose pseudoinverse
temp<-t(H)%*%Dc%*%H
MP<-pseudoinverse(temp)
PhDc<-H%*%MP%*%t(H)%*%Dc
#sqrDr is the square of Dr
sqrDr<-sqrt(Dr)
#sqrDc is the square of Dc
sqrDc<-sqrt(Dc)
#Zs is a "standardized" data matrix (accounted for by G & H)
Zs<-sqrDr%*%PgDr%*%sqriDr%*%Z%*%sqriDc%*%t(PhDc)%*%sqrDc
#SVD of Zs
d <- diag(svd(Zs)$d)
u <- svd(Zs)$u
v <- svd(Zs)$v
dd<-diag(t(d))
print('SS accounted for by G & H')
SST<-t(dd)%*%dd
SST
print('Squared singular values for each dimension')
dde<-dd*dd
dde
print('Percentage of contribution (out of SS accounted for by G & H)')
dde/SST

#Column representation
V<-sqrN*sqriDc%*%v[,1:r]
V[6,1]<-V[6,1]+.05
#Plots of configurations of size of classes of cars(Constrained CA)
dev.new()
plot.new()
#Specify Limits of Axes
plot(-2.5:2.5, -2:3, type="n",axes="F")
#Draw axes
Z1<-c(-2.5, 2.5, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -2, 3)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Heading for the plot
title(main = '(a)')
#Define labels for plotting
labc<-c('A','B','C','D','E','F','G','H','I','J','K','L','M','N')
#For each of 14 size classes, component loadings are ploted for 
#Compnents 1 (x-axis) against 2 (y-axis)
for (i in 1:p)
	text(V[i,1],V[i,2],labc[i])

#Row representation
U<-sqrN*sqriDr%*%u[,1:r]%*%d[1:r,1:r]
#Plots of age and income groups of purchasers(Unconstrained CA)
dev.new()
plot.new()
#Specify Limits of Axes
plot(c(-0.7,0.7), c(-0.7,0.7), type="n",axes="F")
#Draw axes
Z1<-c(-0.7, 0.7, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -0.7, 0.7)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Heading for the plot
title(main = '(b)')
#plot points(x,y given) using solid lines
lines(U[1:9,1],U[1:9,2])
lines(U[46:54,1],U[46:54,2])
lines(U[55:63,1],U[55:63,2])
lines(U[1+9*(0:6),1],U[1+9*(0:6),2])
lines(U[9+9*(0:6),1],U[9+9*(0:6),2])

