#This program fits a special case of CPCA called the 
#redundancy analysis (RA) model. It first decomposes 
#the original data matrix into the between-group and 
#within-group data matrices by External Analysis
#then applies PCA to the decomposed components.
#
#Read the data file; The mezzich's data contains ratings 
#of four archtypal psychiatric diseases by 11 
#psychiatrists using 17 rating scales
mezzich.data <-read.table("mezzich.txt")
#Assign the data matrix to X excluding the case number 
#in the first column
X<-mezzich.data[,2:18]
#Get the dimension of the data matrix
x<-dim(X)
N<-x[1]
p<-x[2]
#Get the rowise centered matrix XX with respect to the row means
X<-t(t(X))
XX<-X-rowMeans(X)
#D is the inverse of the diagonal matrix of standard deviations in the 
#diagonal
D<-sqrt(solve(diag(diag(XX%*%t(XX)/p))))
#Z is a matrix of rowwise "standardized" data obtained 
#by premultiplicating XX by D
Z<-D%*%XX
#SVD of Z (u: the matrix of left signular vectors, d: the diagonal 
#nonzero singular values, v: the matrix of right singular vectors)
d <- diag(svd(Z)$d)
u <- svd(Z)$u
v <- svd(Z)$v
#r is the number of component to be retained
r<-2
#The square root of N needed to scale component scores
sqrtN<-sqrt(N)
#Component loadings 
A<-v[,1:r]%*%d[1:r,1:r]/sqrtN
#Component scores
F=sqrtN*u[,1:r]
#Assign diagonal elements of d to vector dd
dd<-diag(d)
#Squared singular values
dde<-dd*dd
print('The total SS')
SST<-t(dd)%*%dd
SST
print('The SS explained by each components')
t(dde)
print('The percentage that SSs explained by each component')
dde/SST

#Reflect the second column of A
A[,2]<--A[,2]
#Plots of component loadings
dev.new()
plot.new()
#Specify Limits of Axes
plot(-1.5:1.5, -1.5:1.5, type="n",axes="F") 
#Heading for the plot
title(main ='(a)')
#Draw axes
Z1<-c(-1.3, 1.3, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -1.3, 1.3)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Define labels for plotting
labl<-c('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q')
#For each of 17 rows of A, component loadings are ploted for 
#Compnents 1 (x-axis) against 2 (y-axis)
for (i in 1:17)
	text(A[i,1],A[i,2],labl[i])

#Reflect the second column of F (in accordance with the 
#reflection of the second column of A
F[,2]<--F[,2]
#Build a vector of length 11 containing the value 1 in all position
e<-rep(1,11)
#Build a 44x4 matrix G of dummy variables where the four columns represent 
#the four diagnostic categories, and the rows represent the 44 sets of 
#ratings.
zeros<- rep(0,11)
G1<-cbind(e, zeros, zeros, zeros)
G2<-cbind(zeros, e, zeros, zeros)
G3<-cbind(zeros, zeros, e, zeros)
G4<-cbind(zeros, zeros, zeros, e)
G<-rbind(G1,G2,G3,G4)
#Plots of component scores
dev.new()
plot.new()
#Jittering some of the points
M<-solve(t(G)%*%G)%*%t(G)%*%F
M[2,1]<-M[2,1]+.04
M[2,2]<-M[2,2]+.02
M[3,1]<-M[3,1]-.02
M[3,2]<-M[3,2]+.09
#Specify Limits of Axes
plot(-2:2, -2:2, type="n",axes="F")
#Heading for the plot
title(main ='(b)')
#Draw axes
Z1<-c(-1.7, 1.7, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -2, 2)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
#Define point labels
labs<-c('a','b','c','d')
#Define group centroid labels
labg<-c('1','2','3','4')
ij<-0
for (i in 1:4){
	#Plot the group centroids with integer labels
    	text(M[i,1],M[i,2],labg[i])
    	for (j in 1:11){
        	ij<-ij+1
		#Plot points in each group with alphabetic labels
		text(F[ij,1],F[ij,2],labs[i])
    }
}

#The between-group data matrix
PgZ<-G%*%solve(t(G)%*%G)%*%t(G)%*%Z
print('The between groups SS')
SSB<-sum(diag(t(PgZ)%*%PgZ))
SSB
print('Percentage of external analysis of the between groups')
SSB/SST
#SVD of PgZ
d1 <- diag(svd(PgZ)$d)
u1 <- svd(PgZ)$u
v1 <- svd(PgZ)$v
#Component loadings
A<-v1[,1:r]%*%d1[1:r,1:r]/sqrtN
#Two-component solution was extracted
F<-sqrtN*u1[,1:r]
#Assign diagonal elements of d1 to dd
dd<-diag(d1)
#Squared the diagonal nonzero singular values
dde<-dd*dd
print('The SS explained by each component from the between-group data')
print('matrix')
t(dde)
print('The percentage that SS explained by each component from the')
print('between-group data matrix')
dde/SST
#Reflect the second column of A
A[,2]<--A[,2]
#Plots of component loadings by CPCA between-group differences
dev.new()
plot.new()
plot(-1.5:1.5, -1.5:1.5, type="n",axes="F") 
title(main ='(a)')
Z1<-c(-1.5, 1.5, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -1.5, 1.5)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
for (i in 1:17)
	text(A[i,1],A[i,2],labl[i])

#The within-group data matrix
QgZ<-Z-PgZ
print('The within-group SS')
SSW<-sum(diag(t(QgZ)%*%QgZ))
SSW
print('Percentage of external analysis of the within-group')
SSW/SST
#SVD of QgZ
d2 <- diag(svd(QgZ)$d)
u2 <- svd(QgZ)$u
v2 <- svd(QgZ)$v
#Component loadings
A<-v2[,1:r]%*%d2[1:r,1:r]/sqrtN
#Two-component solution was extracted
F<-sqrtN*u2[,1:r]
#Assign diagonal elements of d1 to dd
dd<-diag(d2)
#Squared the diagonal nonzero singular values
dde<-dd*dd
print('The SS explained by each component from the within-group data')
print('matrix')
t(dde)
print('The percentage that SS explained by each component from the')
print('within-group data matrix')
dde/SST

#Plots of component loadings by CPCA within-group differences
dev.new()
plot.new()
A<-v2[,1:r]%*%d2[1:r,1:r]/sqrtN
A[17,1]<-A[17,1]-.02
A[3,1]<-A[3,1]-.03
A[1,2]<-A[1,2]+.01
A[13,2]<-A[13,2]-.01
plot(-0.5:0.5, -0.5:0.5, type="n",axes="F")
title(main ='(b)')
Z1<-c(-.75, .75, 0, 0)
dim(Z1)<-c(2,2)
lines(Z1, col="blue", lwd=2)
Z2=c(0, 0, -.75, .75)
dim(Z2)<-c(2,2)
lines(Z2, col="blue", lwd=2)
for (i in 1:17)
	text(A[i,1],A[i,2],labl[i])


