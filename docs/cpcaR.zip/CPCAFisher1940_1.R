#This program analyzes a contingency table of Tocher's data by 
#correspondence analysis(CA) and constrained CA(CCA)where the external 
#information represents certain hypotheses, and use chi-square tests to 
#test these hypotheses. The external information is also used for 
#assessing how much of the variability in the original data can be 
#explained by the external information.
#
#Insert the table of Tocher's eye color and hair color
#The table is classified subjects into four categories of eye color ( Blue,
#Light, Medium, and Dark) and five categories of hair color ( Faie, Red, 
#Medium, Dark, and Black).
F<-matrix(c(326,688,343,98,
	38,116,84,48,
	241,584,909,403,
	110,188,412,681,
	3,4,26,85), nrow=4, ncol=5)
#Get the dimension of data matrix
x<-dim(F)
R<-x[1]
C<-x[2]
#k is the sum of rows(eye color)
k<-colSums(t(F))
#K is the diagonal matrix of row totals
K<-k
#N is the total sample size
N<-sum(K)
#L is the diagonal matrix of column totals
L<-diag(colSums(F))
#invk is the inverse matrix of K
invK <-solve(diag(K))
#invL is the inverse matrix of L
invL <- solve(L)
#sqriK is the square root of invK
sqriK<-sqrt(invK)
#sqriL is the square root of invL
sqriL<-sqrt(invL)
K<-rep(K,C)
dim(K)<-c(R,C)
#A is a "standardized" data matrix
A<-sqriK%*%(F-K%*%L/N)%*%sqriL
#Total association between rows and columns of the contingency table
Chi1<-N%*%sum(diag(t(A)%*%A))
print('Value of total chi-square')
Chi1
#Decompose A to u,d,v
d <- svd(A)$d
u <- svd(A)$u
v <- svd(A)$v
#sqrN is the square root of total sample size
sqrN<-sqrt(N)
K<-k
K<-diag(K)
U<-(sqrN*sqriK)%*%u[,1]*d[1]
print('Row scores')
U

#Define three contrast vectors each represents a specific hypothesis about
#the rows of the contingency table 
#T1 represents the difference between the first two rows of the table
T1<-matrix(c(-1,1,0,0), nrow=4, ncol=1)
#The first column of T2 represents a linear trend in row scores affter the
#first two rows are merged into one. The second column of T2 represents all
#remaining variation among the rows of the table.
T2<-matrix(c(-3,-3,1,5,1,1,-4,2),nrow=4, ncol=2)
#First apply CA with T2 as external information, and take residual from
#this analysis.
#Build a vector of length R containing the value 1 in all position
e<-rep(1,R)
dim(e)<-c(R,1)
#sqrK is the square root of K
sqrK<-sqrt(K)
#sqrL is the square root of L
sqrL<-sqrt(L)
#Q is the adjusted matrix
Q<-diag(R)-e%*%solve(t(e)%*%K%*%e)%*%t(e)%*%K
#G is the information matrix due to T2 ignoring T1
G<-Q%*%T2
#B is the "standardized" data matrix due to T2 ignoring T1
B<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi2<-N%*%sum(diag(t(B)%*%B))
print('Chi-square due to T2 ignoring T1')
chi2

#G is the information matrix due to T1 eliminating T2
G<-invK%*%T1
#E is the "standardized" data matrix due to T1 eliminating T2
E<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi3<-N%*%sum(diag(t(E)%*%E))
print('Chi-square due to T1 eliminating T2')
chi3
#chi2 and chi3 should add up to the total chi-square
print('Total chi-square (sum of chi2 and chi3)')
chi2+chi3
Chi1

#G is the information matrix due to T1 ignoring T2
G<-Q%*%T1
#B is the "standardized" data matrix due to T1 ignoring T2
B<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi2<-N%*%sum(diag(t(B)%*%B))
print('Chi-square for T1 ignoring T2')
chi2

#G is the information matrix due to T2 eliminating T1
G<-invK%*%T2
#E is the "standardized" data matrix due to T2 eliminating T1
E<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi3<-N%*%sum(diag(t(E)%*%E))
print('Chi-square for T2 eliminating T1')
chi3
#Again, chi2 and chi3 should add up to the total chisquare
print('Total chi-square (sum of chi2 and chi3)')
chi2+chi3
Chi1

#Second, fit the second column of T2, and take residuals from this
#analysis by interchanging the hypothesis contrast vectors:
#Assign the first column of T2 to T3
T3<-T2[,1]
dim(T3)<-c(4,1)
#Assign T1 to the first column of T2
T2=cbind(T1, T2[,2])
#Assign T3 to T1, now T1 is the first column of the original T2.
T1<-T3
dim(T1)<-c(4,1)

#G is the information matrix due to T1 ignoring T2
G<-Q%*%T1
#B is the "standardized" data matrix due to T1 ignoring T2
B<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi2<-N%*%sum(diag(t(B)%*%B))
print('Chi-square for T1 ignoring T2')
chi2
#Decompose B to u,d,v
d <- svd(B)$d
u <- svd(B)$u
v <- svd(B)$v
#sqrN is the square root of N
sqrN<-sqrt(N)
print('Row scores')
sqrN*sqriK%*%u[,1]*d[1]

#G is the information matrix due to T2 eliminating T1
G<-invK%*%T2
#E is the "standardized" data matrix due to T2 eliminating T1
E<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi3<-N%*%sum(diag(t(E)%*%E))
print('Chi-square for T2 eliminating T1')
chi3
#Decompose E to u,d,v
d <- svd(E)$d
u <- svd(E)$u
v <- svd(E)$v
print('Row scores')
sqrN*sqriK%*%u[,1]%*%d[1]
print('Total chi-square (sum of chi2 and chi3)')
chi2+chi3
Chi1

#G is the information matrix due to T1 eliminating T2
G<-invK%*%T1
#E is the "standardized" data matrix due to T1 eliminating T2
E<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi3<-N%*%sum(diag(t(E)%*%E))
print('Chi-square for T1 eliminating T2')
chi3
#Decompose E to u,d,v
d <- svd(E)$d
u <- svd(E)$u
v <- svd(E)$v
print('Row scores')
sqrN*sqriK%*%u[,1]%*%d[1]

#G is the information matrix due to T2 ignoring T1
G<-Q%*%T2
#B is the "standardized" data matrix due to T2 ignoring T1
B<-sqrK%*%G%*%solve(t(G)%*%K%*%G)%*%t(G)%*%F%*%sqriL
chi2<-N%*%sum(diag(t(B)%*%B))
print('Chi-square for T2 ignoring T1')
chi2
#Decompose B to u,d,v
d <- svd(B)$d
u <- svd(B)$u
v <- svd(B)$v
print('Row scores')
sqrN*sqriK%*%u[,1]%*%d[1]

