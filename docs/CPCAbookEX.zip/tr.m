function tmdl=tr(tform,mdl,ir,nr)
tmdl=zeros(nr,1);
for i=1:nr
tmdl(i)=mdl(ir(i));
end %i
mdl=trany(tmdl,tform,nr);
for i=1:nr
tmdl(ir(i))=mdl(i);
end %i
