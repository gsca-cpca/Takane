%This program fits a special case of CPCA called the 
%redundancy analysis (RA) model. It first decomposes 
%the original data matrix into the between-group and 
%within-group data matrices by External Analysis
%then applies PCA to the decomposed components.
%
%Read the data file; The mezzich's data contains ratings 
%of four archtypal psychiatric diseases by 11 
%psychiatrists using 17 rating scales
load mezzich.txt
%Assign the data matrix to X excluding the case number 
%in the first column
X=mezzich(:,2:18);
%Get the dimensions of the data matrix
[N p]=size(X);
%Get the rowise centered matrix XX with respect to the 
%row means
XX=X-sum(X')'*ones(1,p)/p;
%D is the inverse of the diagonal matrix of standard 
%deviations in the diagonal
D=sqrt(inv(diag(diag(XX*XX'/p))));
%Z is a matrix of rowwise "standardized" data obtained 
%by premultiplicating XX by D
Z=D*XX;
%SVD of Z (u: the matrix of left signular vectors), d: 
%the diagonal %nonzero singular values, v: the matrix of 
%right singular vectors)
[u d v]=svd(Z,0);
%r is the number of components to be retained
r=2;
%The square root of N needed to scale component scores
sqrtN=sqrt(N);
%Component loadings 
A=v(:,1:r)*d(1:r,1:r)/sqrtN;
%Component scores
F=sqrtN*u(:,1:r);
%Assign diagonal elements of d to vector dd
dd=diag(d);
%Squared singular values
dde=dd.*dd;
fprintf('The total SS')
SST=dd'*dd
fprintf('The SS explained by each components')
dde'
fprintf('The percentage that SSs explained by each component')
dde'/SST

%Reflect the second column of A
A(:,2)=-A(:,2);
%Plots of component loadings
figure(1)
%Define labels for plotting
labl=['A';'B';'C';'D';'E';'F';'G';'H';'I';'J';'K';'L';'M';'N';'O';'P';'Q'];
%For each of 17 rows of A, component loadings are ploted for 
%Compnents 1 (x-axis) against 2 (y-axis) 
for i=1:17
text(A(i,1),A(i,2),labl(i))
end
%Declare that there will be more to be added to the same graph
hold on
%Heading for the plot
title('(a)')
%Specify Limits of Axes
axis([-1.5 1.5 -1.5 1.5])
%Make the plot square
axis('square')
%Draw axes
Z1=[-1.3 0;
    1.3 0];
Z2=[0 -1.3;
    0 1.3];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Erase the original axes
axis('off')
%Declare there is nothing more to be added 
hold off

%Reflect the second column of F (in accordance with the 
%reflection of the second column of A
F(:,2)=-F(:,2);
%Build a vector of length 11 containing the value 1 in all 
%position
e=ones(11,1);
%Build a 44x4 matrix G of dummy variables where the four 
%columns represent the four diagnostic categories, and the 
%rows represent the 44 sets of ratings.
G=[e zeros(11,3);
    zeros(11,1) e zeros(11,2);
    zeros(11,2) e zeros(11,1);
    zeros(11,3) e];
%Plots of component scores
figure(2)
M=inv(G'*G)*G'*F;
%Jittering some of the points
M(2,1)=M(2,1)+.04;
M(2,2)=M(2,2)+.02;
M(3,1)=M(3,1)-.02;
M(3,2)=M(3,2)+.09;
%Define point labels
labs=['a';'b';'c';'d'];
%Define group centroid labels
labg=['1';'2';'3';'4'];
ij=0;
for i=1:4
    %Plot the group centroids with integer labels
    text(M(i,1),M(i,2),labg(i))
    for j=1:11
        ij=ij+1;
        %Plot points in each group with alphabetic 
        %labels
        text(F(ij,1),F(ij,2),labs(i))
    end
end
hold on
title('(b)')
axis([-2 2 -2 2])
axis('square')
%Draw axes
Z1=[-1.7 0;
    1.7 0];
Z2=[0 -2;
    0 2];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Remove original axes
axis('off')
hold off

%The between-group data matrix
PgZ=G*inv(G'*G)*G'*Z;
fprintf('The between groups SS')
SSB=trace(PgZ'*PgZ)
fprintf('Percentage of external analysis of the between groups')
SSB/SST
%SVD of PgZ
[u1 d1 v1]=svd(PgZ,0);
%Component loadings
A=v1(:,1:r)*d1(1:r,1:r)/sqrtN;
%Two-component solution was extracted
F=sqrtN*u1(:,1:r);
%Assign diagonal elements of d1 to dd
dd=diag(d1);
%Squared the diagonal nonzero singular values
dde=dd.*dd;
fprintf('The SS explained by each component from the between-group data\n')
fprintf('matrix')
dde'
fprintf('The percentage that SS explained by each component from the \n')
fprintf('between-group data matrix')
dde'/SST
%Interchange the sign of second column of A
A(:,2)=-A(:,2);
%Plots of component loadings by CPCA between-group differences
figure(3)
for i=1:17
text(A(i,1),A(i,2),labl(i))
end
hold on
title('(a)')
axis([-1.5 1.5 -1.5 1.5])
axis('square')
Z1=[-1.5 0;
    1.5 0];
Z2=[0 -1.5;
    0 1.5];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
axis('off')
hold off

%The within-group data matrix
QgZ=Z-PgZ;
fprintf('The within-group SS')
SSW=trace(QgZ'*QgZ)
fprintf('Percentage of external analysis of the within-group')
SSW/SST
%SVD of QgZ
[u2 d2 v2]=svd(QgZ,0);
%Component loadings
A=v2(:,1:r)*d2(1:r,1:r)/sqrtN;
%Two-component solution was extracted
F=sqrtN*u2(:,1:r);
%Assign diagonal elements of d1 to dd
dd=diag(d2);
%Squared the diagonal nonzero singular values
dde=dd.*dd;
fprintf('The SS explained by each component from the within-group data\n')
fprintf('matrix')
dde'
fprintf('The percentage that SS explained by each component from the \n')
fprintf('within-group data matrix')
dde'/SST

%Plots of component loadings by CPCA within-group differences
figure(4)
A=v2(:,1:r)*d2(1:r,1:r)/sqrtN;
A(17,1)=A(17,1)-.02;
A(3,1)=A(3,1)-.03;
A(1,2)=A(1,2)+.01;
A(13,2)=A(13,2)-.01;
for i=1:17
text(A(i,1),A(i,2),labl(i))
end
hold on
title('(b)')
axis([-.75 .75 -.75 .75])
axis('square')
Z1=[-.75 0;
    .75 0];
Z2=[0 -.75;
    0 .75];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
axis('off')
hold off
