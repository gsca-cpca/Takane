%NSCA: abortion data
%This program performs NSCA and NSCCA 
%on the abortion data
%
%The 9 by 3 contingency table
%The 9 rows represent respondent profiles defined by
%factorially combining 3 reigious groups (northern 
%protestant (np), southern protestant (sp), and 
%catholic (ct)), and 3 education levels (1 = less than 8, 
%2 = between 9 and 12, 3 = more than 12). The first 3 
%rows represent the 3 levels of education for np, the next
%3 rows for sp, andthe last 3 rows ct. The 3 columns in
% the table represent attitude toward abortion (1 = positive,
%2 = neutral, 3 = negative).
F=[49 46 115;
    293 140 277;
    244 66 100;
    27 34 117;
    134 98 167;
    138 38 73;
    25 40 88;
    172 103 312;
    93 57 135];
C=3;
K=diag(sum(F'));
Kinv=inv(K);
Ksq=sqrt(K);
Ki2=inv(Ksq);
N=sum(diag(K));
c=(C-1)*(N-1);
sqrtN=sqrt(N);
e=ones(9,1);
Q=eye(9)-e*inv(e'*K*e)*e'*K;
%
L=diag(sum(F));
TSS=1-trace(L*L)/(N*N);
%Linv=inv(L);
%Lsq=sqrt(L);
%Li2=inv(sqrt(L));
A=Ki2*Q'*F;
BSSa=trace(A'*A)/N;
tauA=BSSa/TSS
Ca=c*tauA
[u d v]=svd(A,0);
U=sqrtN*Ki2*u(:,1);
100*d(1,1)^2/(N*TSS*tauA)
d(1,1)
%Define T1
T1=[1 0 1 1;
    0 0 1 1;
    -1 0 1 1;
    1 0 -1 1;
    0 0 -1 1;
    -1 0 -1 1;
    0 1 0 -2;
    0 0 0 -2;
    0 -1 0 -2];
%T1 ignoring T2
X=Q*T1;
B=Ksq*X*inv(X'*K*X)*X'*F;
BSSb=trace(B'*B)/N
tauB=BSSb/TSS
Cb=c*tauB
[u1 d1 v1]=svd(B,0);
U=sqrtN*Ki2*u1(:,1)
100*d1(1,1)^2/(N*TSS*tauB)
d1(1,1)

%T1 eliminating T2
XX=Kinv*T1;
E=Ksq*XX*inv(XX'*K*XX)*XX'*F;
BSSe=trace(E'*E)/N;
tauE=BSSe/TSS
Ce=c*tauE
[u2 d2 v2]=svd(E,0);
U=sqrtN*Ki2*u2(:,1)
100*d2(1,1)^2/(N*TSS*tauE)
d2(1,1)

%%%%%%%%%%%%%%%%%%%%%%%%%%
%Define T2
T2=[1 0 0 1;
    -2 0 0 -1;
    1 0 0 0;
    0 1 0 -1;
    0 -2 0 1;
    0 1 0 0;
    0 0 1 0;
    0 0 -2 0;
    0 0 1 0];
%T2 ignoring T1
X=Q*T2;
J=Ksq*X*inv(X'*K*X)*X'*F;
BSSj=trace(J'*J)/N;
tauJ=BSSj/TSS
Cj=c*tauJ
[u3 d3 v3]=svd(J,0);
U=sqrtN*Ki2*u3(:,1);
100*d3(1,1)^2/(N*TSS*tauJ)
d3(1,1)

%T2 eliminating T1
XX=Kinv*T2;
LL=Ksq*XX*inv(XX'*K*XX)*XX'*F;
BSSl=trace(LL'*LL)/N;
tauL=BSSl/TSS
Cl=c*tauL
[u4 d4 v4]=svd(LL,0);
U=sqrtN*Ki2*u1(:,1);
100*d4(1,1)^2/(N*TSS*tauL)
d4(1,1)

%Check the additivities
Ca
Cb+Cl
Ce+Cj

