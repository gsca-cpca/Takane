%CANO reduces to canonical discriminant analysis (CDA) 
%when one of two sets %of variables consists of dummy-coded 
%categorical variables. This program %applied CDA to the 
%Fisher's (1936) iris data to discriminate among the species.
%
%Read the data file; The fisheriris data consists of 50 
%samples from each of the three species of iris (setosa, 
%verginica, and versicolor) with four %features measured 
%from each sample(length, width, sepals, and petals).
load iris.txt;
%Extract the data called meas to XX
XX=iris;
%n is for 150 samples
[n m]=size(XX);
%Get the columnwise centered matrix X with respect to the means
X=XX-ones(n,1)*mean(XX);
%Build a 150x3 matrix G of dummy variables indicating group memberships of
%cases(subjects)
G=[ones(50,1) zeros(50,2);
    zeros(50,1) ones(50,1) zeros(50,1);
    zeros(50,2) ones(50,1)];
%K is the variance of G
K=G'*G;
%Ksqi is the square root and inverse of matrix K
Ksqi=sqrt(inv(K));
%X2 is the variance-covariance of X (multiplied by n)
X2=X'*X;
%SVD of X2
[u d v]=svd(X2);
Xsqi=v*sqrt(inv(d))*u';
A=Ksqi*G'*X*Xsqi;
%SVD of A
[u1 d1 v1]=svd(A);
%Weight matrix for G
U=Ksqi*u1(:,1:2)*d1(1:2,1:2);
%Weight matrix for X
V=Xsqi*v1(:,1:2);
fprintf('Correlations among species')
diag(d1)'
%Fisher's result
Uc=[-5 1;
    1 -3;
    4 2];
fprintf('Correlation between the result of')
fprintf('discriminant analysis and that of Fisher')
corr(U,Uc)

fprintf('Weights applied to G, indicators of group') 
fprintf('memberships')
u1(:,1:2)
fprintf('Weights for the predictor variables')
v1(:,1:2)

%Plot of the result
%Label: squares indicate setosa, asterisks indicate 
%versicolor, and circles virginia.
lbl=['s';'*';'o'];
Vx=X*V;
ie=0;
%For each of 3 species, the results are plotted for 
%component 1 (x-axis) against 2 (y-axis)
for i=1:3
ib=ie+1;
ie=ie+50;
plot(Vx(ib:ie,1),Vx(ib:ie,2),lbl(i),'Color','r')
hold on
end
%Make the plot square
axis('square')
%Remove the default axes
axis('off')
%Specify limits of axes
axis([-.3 .3 -.3 .3]);
%Three integers indicate the centroids of the three species(1 setosa; 2 
%versicolor; 3 virginica).
lbc=['1';'2';'3'];
text(U(:,1),U(:,2),lbc,'Color','k')
%Draw axes
A=[-.25 0;
    .25 0];
plot(A(:,1),A(:,2))
B=[0 -.25;
    0 .25];
plot(B(:,1),B(:,2))
%Declare there is nothing more to be added
hold off

