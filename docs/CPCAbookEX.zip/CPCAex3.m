%This program first performs correspondence analysis (CA), also known as 
%dual scaling (DS) to analyze a cross classification table (in finding 
%out which size classes of cars are more and less popular among which age 
%and income groups). It then fits canonical corrspondence analysis (CCA), 
%which is a special case of CA. (The constrained CA is performed by 
%incorporating the information on age and income in the representation of 
%the rows and the information on size classes in the representation of 
%the columns of the table).
%
%Read the data file; The car data contain a cross-tabulation of cars 
%purchased in terms of class size of the car (classified into 14 class
%sizes), age (classified into 7 groups) and income of purchasers 
%(classified into 9 groups).
load car.txt
%Assign the data matrix to F excluding the age and income variable number 
%in the first and second column
F=car(:,3:16);
%Get the dimensions of the data matrix
[n p]=size(F);
%Dr is the diagonal matrix with row totals of the table as the diagonal 
%elements
Dr=diag(sum(F'));
%invDr is the inverse of Dr
invDr=inv(Dr);
%sqriDr is the square of invDr
sqriDr=sqrt(invDr);
%c is the vector of column totals
c=sum(F);
%N is the total sample size
N=sum(c);
%Dc is the diagonal matrix with column totals as the diagonal elements
Dc=diag(c);
%incDc is the inverse of Dc
invDc=inv(Dc);
%sqriDc is the square root of InvDc
sqriDc=sqrt(invDc);
%Z is a "standardized" data matrix (with a trivial component eliminated) 
Z=sqriDr*(F-Dr*ones(n,1)*ones(1,p)*Dc/N)*sqriDc;
%SVD of Z (u: the matrix of left signular vectors, d: the diagonal 
%nonzero singular values, v: the matrix of right singular vectors)
[u d v]=svd(Z,0);
%Assign diagonal elements of d(transposed) to vector dd
dd=diag(d)';
fprintf('The total SS')
SST=dd*dd'
fprintf('Squared sigunlar values for each dimension')
dde=dd.*dd
fprintf('Percentage of contribution')
dde/SST
%r is the number of components to be retained
r=2;
%The square root of N
sqrN=sqrt(N);
%Row representaton in principal coordinates
U=sqrN*sqriDr*u(:,1:r)*d(1:r,1:r);
%Column representation in standard coordinates
V=sqrN*sqriDc*v(:,1:r);
%Reflect the second column of V
V(:,2)=-V(:,2);
%Gitter some points
V(11,1)=V(11,1)-.05;
%Plots of configurations of size of classes of cars(Unconstrained CA)
figure(1)
%Define labels for plotting
labc=['A';'B';'C';'D';'E';'F';'G';'H';'I';'J';'K';'L';'M';'N'];
%For each of 14 size classes, component loadings are ploted for 
%Compnents 1 (x-axis) against 2 (y-axis)
for i=1:p
text(V(i,1),V(i,2),labc(i))
end
%Declare that there will be more to be added to the same graph
hold on
%Heading for the plot
title('(a)')
%Specify Limits of Axes
axis([-2.5 2.5 -2 3])
%Make the plot square
axis('square')
%Draw axes
Z1=[-2.5 0;
    2.5 0];
Z2=[0 -2;
    0 3];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Remove default axes
axis('off')
%Declare there is nothing more to be added
hold off

%Row representation
U=sqrN*sqriDr*u(:,1:r)*d(1:r,1:r);
%Reflect the second column of U
U(:,2)=-U(:,2);
%Plots of age and income groups of purchasers (Unconstrained CA)
figure(2)
%plot points(x,y given) using solid lines
plot(U(1:9,1),U(1:9,2))
%Declare that there will be more to be added to the same graph
hold on
%Heading for the plot
title('(b)')
%plot points(x,y given) using solid lines
plot(U(46:54,1),U(46:54,2))
plot(U(55:63,1),U(55:63,2))
plot(U(1:9:55,1),U(1:9:55,2))
plot(U(9:9:63,1),U(9:9:63,2))
%Specify Limits of Axes
axis([-.7 .7 -.7 .7])
%Make the plot square
axis('square')
%Draw axes
Z1=[-.7 0;
    .7 0];
Z2=[0 -.7;
    0 .7];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Remove the original axes
axis('off')
%Declare there is nothing more to be added
hold off
%Build a vector of length 9 containing the value 1 in all position
e=ones(9,1);
%ii is a 9x9 identity matrix
ii=eye(9);
%Build a 63x16 of age and income information matrix G1 of dummy variables 
%where the first 7 columns are the 9-component vector of ones, and the 
%last 9 columns are the identity matrix of order 9 with respect to each
%component.
G1=[e zeros(9,6) ii;
    zeros(9,1) e zeros(9,5) ii;
    zeros(9,2) e zeros(9,4) ii;
    zeros(9,3) e zeros(9,3) ii;
    zeros(9,4) e zeros(9,2) ii;
    zeros(9,5) e zeros(9,1) ii;
    zeros(9,6) e ii];
%Build a 14x11 of size classes information matrix H1 of dummy variables
%where the first 6 columns represent the size, and the last 5 columns
%represent the luxuriousness of cars.
H1=[1 0 0 0 0 0 0 1 0 0 0;
   1 0 0 0 0 0 1 0 0 0 0;
   0 0 0 0 0 0 1 0 0 0 0;
   0 1 0 0 0 0 0 0 0 1 0;
   0 1 0 0 0 0 0 0 1 0 0;
   0 0 1 0 0 0 0 0 0 1 0;
   0 0 1 0 0 0 0 0 1 0 0;
   0 0 0 1 0 0 0 0 0 1 0;
   0 0 0 1 0 0 0 0 1 0 0;
   0 0 0 0 1 0 0 0 0 0 0;
   0 0 0 0 0 1 0 0 0 1 0;
   0 0 0 0 0 1 0 1 0 0 0;
   0 0 0 0 0 1 0 0 0 0 1;
   0 0 0 0 0 1 1 0 0 0 0];

Qr=eye(n)-ones(n,1)*ones(1,n)*Dr/N;
%G is the age and income information matrix where the first part represents
%age groups, and the second part income group. 
G=Qr*G1;
Qc=eye(p)-ones(p,1)*ones(1,p)*Dc/N;
%H is the size classes information matrix where the first part represent 
%the size, and the second part represent the luxuriousness of cars.
H=Qc*H1;
%Adjusted Dr accounted for by G using Moore-Penrose pseudoinverse
PgDr=G*pinv(G'*Dr*G)*G'*Dr;
%Adjusted Dc accounted for by G using Moore-Penrose pseudoinverse
PhDc=H*pinv(H'*Dc*H)*H'*Dc;
%sqrDr is the square of Dr
sqrDr=sqrt(Dr);
%sqrDc is the square of Dc
sqrDc=sqrt(Dc);
%Zs is a "standardized" data matrix (accounted for by G & H)
Zs=sqrDr*PgDr*sqriDr*Z*sqriDc*PhDc'*sqrDc;
%The above can also be done by:
%Zs=sqrDr*PgDr*invDr*F*invDc*PhDc'*sqrDc;
%SVD of Zs
[u d v]=svd(Zs,0);
dd=diag(d)';
fprintf('SS accounted for by G & H')
SST=dd*dd'
fprintf('Squared singular values for each dimension')
dde=dd.*dd
fprintf('Percentage of contribution (out of SS accounted for by G & H)')
dde/SST

%Column representaion
V=sqrN*sqriDc*v(:,1:r);
V(6,1)=V(6,1)+.05;
%Plots of configurations of size of classes of cars(Constrained CA)
figure(3)
%Define labels for plotting
labc=['A';'B';'C';'D';'E';'F';'G';'H';'I';'J';'K';'L';'M';'N'];
%For each of 14 size classes, component loadings are ploted for 
%Compnents 1 (x-axis) against 2 (y-axis)
for i=1:p
text(V(i,1),V(i,2),labc(i))
end
%Declare that there will be more to be added to the same graph
hold on
%Heading for the plot
title('(a)')
%Specify Limits of Axes
axis([-2.5 2.5 -2 3])
%Make the plot square
axis('square')
%Draw axes
Z1=[-2.5 0;
    2.5 0];
Z2=[0 -2;
    0 3];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Remove the original axes
axis('off')
%Declare there is nothing more to be added
hold off
%Row representation
U=sqrN*sqriDr*u(:,1:r)*d(1:r,1:r);
%Plots of age and income groups of purchasers(Unconstrained CA)
figure(4)
%plot points(x,y given) using solid lines
plot(U(1:9,1),U(1:9,2))
%Declare that there will be more to be added to the same graph
hold on
%Heading for the plot
title('(b)')
%plot points(x,y given) using solid lines
plot(U(46:54,1),U(46:54,2))
plot(U(55:63,1),U(55:63,2))
plot(U(1:9:55,1),U(1:9:55,2))
plot(U(9:9:63,1),U(9:9:63,2))
%Specify Limits of Axes
axis([-.7 .7 -.7 .7])
%Make the plot square
axis('square')
%Draw axes
Z1=[-.7 0;
    .7 0];
Z2=[0 -.7;
    0 .7];
plot(Z1(:,1),Z1(:,2))
plot(Z2(:,1),Z2(:,2))
%Remove the original axes
axis('off')
%Declare there is nothing more to be added
hold off
