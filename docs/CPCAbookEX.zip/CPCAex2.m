%The first part of the program applies separate PCAs to two sets of 
%variables. Two PCs, one from each set, are then correlated. The
%second part applies redundancy analysis (RA) with one of the two
%sets of variables as predictors, and the other as the criterion
%variables.

%Read the data file; The food contains a 47-case by 6-variable data
%matrix; Four of the six pertain to food variables, andtheremaining 
%two to cancer mortality rates
load food.txt
%Get the dimension of data matrix
[n p]=size(food);
fprintf('The Matrix of Correlation among the six variables')
corr(food)
%Get the means of the six variable
mX=mean(food);
%Get the columnwise centered matrix X with respect to the means 
X=food-ones(n,1)*mX;
%std is a diagonal matrix of standard deviations in the diagonal
std=sqrt(diag(X'*X));
%D is the diagonal matrix of inverse of std
D=inv(diag(std));
%Z is a matrix of "standardized" data. (The standardization is made 
%in such a way that Z'Z gives the correlation matrix rahter than 
%Z'Z/n
Z=X*D;
%p1 is th e number of variables in the first set (food variables)
p1=4;
%Zf is the data matrix of the four variables related to foods
Zf=Z(:,1:p1);
%SVD of Zf (u: the matrix of left signular vectors), d: the diagonal 
%nonzero singular values, v: the matrix of right singular vectors
[u d v]=svd(Zf,0);
%The square root of n needed to scale component scores
sqrn=sqrt(n);
%Extract one component
ff=sqrn*u(:,1);
fprintf('Component loadings')
%Correlations between the component and the observed food variables
af=v(:,1)*d(1,1)
%Squared singular values
a=diag(d*d);
fprintf('The SSs explained by the components and their percentage in')
fprintf('the second column')
[a a/p1*100]
%Do the same thing for the cancer variables
%Zc is the data matrix of two cancer variables
Zc=Z(:,p1+1:p);
%SVD of Zc
[u d v]=svd(Zc,0);
fc=sqrn*u(:,1);
fprintf('Component loadings')
ac=v(:,1)*d(1,1)
a=diag(d*d);
p2=2;
fprintf('The SSs explained by the components and their percentage')
[a a/p2*100]

fprintf('Matrix of the 1st components from food & cancer variables')
F=[ff fc]
fprintf('The matrix of correlation between the two')
corr(F)

%Bipartial correlations after the effect of the 1st component is
%eliminated from each set of variable 
rZ=[Zf-ff*af' Zc-fc*ac'];
fprintf('Bipartial correlation coefficients')
rZ'*rZ

%RA of the cancer variables with respect to the food variables
%Regress Zc onto Zf
fprintf('Rank-free estimates of regression weights W')
W=inv(Zf'*Zf)*Zf'*Zc
%The rank-free prediction matrix
PxY=Zf*W;
%SVD of PxY
[u1 d1 v1]=svd(PxY,0);
dd1=diag(d1);
fprintf('squared singular values')
dsq=dd1.*dd1
fprintf('The total SS')
SST=trace(PxY'*PxY)
fprintf('The percentage of contributions')
100*dsq/SST
fprintf('The redundancy component')
U=sqrn*u1(:,1)
%
V=v1(:,1)*d1(1,1);
fprintf('Weights applied Zf to derive the redundancy components')
Us=inv(Zf'*Zf)*Zf'*U/sqrn
fprintf('Predictor loadings (Correlation between Zf and RC)')
U'*Zf/sqrn
fprintf('Criterion loadings (Correlation between Zc and RC)')
U'*Zc/sqrn

fprintf('Correlations between the 1st PCs for the two sets of')
fprintf('variables with RC')
U'*F/n