%load Z
load mezzich.txt
X=mezzich(:,2:18);
[n p]=size(X);
%Rowwise standardization
XX=X-sum(X')'*ones(1,p)/p;
D=sqrt(inv(diag(diag(XX*XX'/p))));
Z=D*XX;
%The following columnwise standardization 
%is more common in PCA.
%XX=X-ones(n,1)*sum(X)/n;
%D=sqrt(inv(diag(diag(XX'*XX/n))));
%Z=XX*D;

%load G
e=ones(11,1);
G=[e zeros(11,3);
    zeros(11,1) e zeros(11,2);
    zeros(11,2) e zeros(11,1);
    zeros(11,3) e];

C=pinv(G'*G)*G'*Z;
GC=G*C;
[u d v]=svd(GC,0);
r=2;
sqrn=sqrt(n);
%Fo=u(:,1:r)*sqrn;
Do=d(1:r,1:r);
%Ao is the loading matrix from the?original data.
Ao=-v(:,1:r)*Do/sqrn;%reflected right singular 
%vectors to make the configuration in line with 
%Figure 1b.

%bootstrap
nrep=1000;
mA=zeros(p,r);
vA=zeros(p,r);
covA=zeros(p,1);
for k=1:nrep
    id=round(n*rand(n,1)+0.5);
    for i=1:n
        Gb(i,:)=G(id(i),:);
        Zb(i,:)=Z(id(i),:);
    end %i (Created a new boostrap sample.)
    Cb=pinv(Gb'*Gb)*Gb'*Zb;
    GCb=Gb*Cb;
    [u1 d1 v1]=svd(GCb,0);
    Db=d1(1:r,1:r);
    Ab=v1(:,1:r)*Db/sqrn; %the loading matrix 
    %from a bootatrap sample 
    Q=Ab'*Ao;
    [u2 d2 v2]=svd(Q);
    T=u2*v2';
    AbT=Ab*T; %the transformed loading matrix
    %Accumulate for means, variances and 
    %covariances
    mA=mA+AbT;
    vA=vA+AbT.*AbT;
    covA=covA+AbT(:,1).*AbT(:,2);
end

%mean, variance covariance of estimates
mA=mA/nrep;
vA=vA/nrep-mA.*mA;
covA=covA/nrep-mA(:,1).*mA(:,2);

%draw confidence regions
%lblp=[' SC';' A ';' EW';' CD';' GF';' T ';' MP';' GR';' DM';' H ';' S ';' HB';' MR';' U ';' UT';' BA';' E '];
lblp=[' A';' B';' C';' D';' E';' F';' G';' H';' I';' J';' K';' L';' M';' N';' O';' P';' Q'];
CU=[vA(:,1) covA vA(:,2)];
N=size(Z,2);
plot(Ao(:,1),Ao(:,2),'.k');
text(Ao(:,1),Ao(:,2),lblp(:,1:2));
axis([-1.5 1.5 -1.5 1.5])
axis('square');
hold on
for ii=1:p
    dm=cellip(CU(ii,:),Ao(ii,:));
end
Ax=[-1.4 0;
    1.4 0];
plot(Ax(:,1),Ax(:,2),'k')
Ay=[0 1.4;
    0 -1.4];
plot(Ay(:,1),Ay(:,2),'k')
hold off
    
sA=Ao./sqrt(vA);
for i=1:p
    for j=1:2
        p=normcdf(sA(i,j),0,1);
        if p>.5
        pA(i,j)=2*(1-p);
        else
            pA(i,j)=2*p;
        end
    end
end
pA
