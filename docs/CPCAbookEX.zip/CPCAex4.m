%This program analyzes a contingency table (Tocher's data) by 
%correspondence analysis (CA) and constrained CA (CCA), where the external 
%information represents certain hypotheses, and use chi-square tests to 
%test these hypotheses. The external information is also used for 
%assessing how much of the variability in the original data can be 
%explained by the external information.
%
%Insert the table of Tocher's eye color and hair color.
%The table is classified subjects into four categories of eye color (Blue,
%Light, Medium, and Dark) and five categories of hair color (Fair, Red, 
%Medium, Dark, and Black).
F=[326 38 241 110 3;
    688 116 584 188 4;
    343 84 909 412 26;
    98 48 403 681 85];
%Get the dimension of the data matrix
[R C]=size(F);
%k is row totals (eye color)
k=sum(F');
%K is the diagonal matrix of row totals
K=diag(k);
%N is the total sample size
N=sum(k);
%L is the diagonal matrix of column totals
L=diag(sum(F));
%invk is the inverse matrix of K
invK=inv(K);
%invL is the inverse matrix of L
invL=inv(L);
%sqriK is the square root of invK
sqriK=sqrt(invK);
%sqriL is the square root of invL
sqriL=sqrt(invL);
%A is a "standardized" data matrix
A=sqriK*(F-K*ones(R,1)*ones(1,C)*L/N)*sqriL;
fprintf('The value of total chi-square')
%Total association between rows and columns of the contingency table
Chi1=N*trace(A'*A)
%Decompose A to u,d,v
[v d u]=svd(A',0);
%sqrN is the square root of total sample size
sqrN=sqrt(N);
fprintf('Row scores')
U=sqrN*sqriK*u(:,1)*d(1,1)

%Define three contrast vectors each represents a specific hypothesis about
%the rows of the contingency table 
%T1 represents the difference between the first two rows of the table
T1=[-1; 1; 0; 0];
%The first column of T2 represents a linear trend in row scores affter the
%first two rows are merged into one. The second column of T2 represents all
%remaining variation among the rows of the table.
T2=[-3 1; -3 1; 1 -4; 5 2];
%First apply CA with T2 as external information, and take residual from
%this analysis.
%Build a vector of length R containing the value 1 in all position
e=ones(R,1);
%sqrK is the square root of K
sqrK=sqrt(K);
%sqrL is the square root of L
sqrL=sqrt(L);
%Q is the adjusted matrix
Q=eye(R)-e*inv(e'*K*e)*e'*K;
%G is the information matrix due to T2 ignoring T1
G=Q*T2;
%B is the "standardized" data matrix due to T2 ignoring T1
B=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square due to T2 ignoring T1')
chi2=N*trace(B'*B)

%G is the information matrix due to T1 eliminating T2
G=invK*T1;
%E is the "standardized" data matrix due to T1 eliminating T2
E=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square due to T1 eliminating T2')
chi3=N*trace(E'*E)
fprintf('Total chi-square (sum of chi2 and chi3)')
%chi2 and chi3 should add up to the total chi-square
chi2+chi3
Chi1

%G is the information matrix due to T1 ignoring T2
G=Q*T1;
%B is the "standardized" data matrix due to T1 ignoring T2
B=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T1 ignoring T2')
chi2=N*trace(B'*B)

%G is the information matrix due to T2 eliminating T1
G=invK*T2;
%E is the "standardized" data matrix due to T2 eliminating T1
E=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T2 eliminating T1')
chi3=N*trace(E'*E)
fprintf('Total chi-square (sum of chi2 and chi3)')
%Again, chi2 and chi3 should add up to the total chisquare
chi2+chi3
Chi1

%Second, fit the second column of T2, and take residuals from this
%analysis by interchanging the hypothesis contrast vectors:
%Assign the first column of T2 to T3
T3=T2(:,1);
%Assign T1 to the first column of T2
T2=[T1 T2(:,2)];
%Assign T3 to T1, now T1 is the first column of the original T2.
T1=T3;

%G is the information matrix due to T1 ignoring T2
G=Q*T1;
%B is the "standardized" data matrix due to T1 ignoring T2
B=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T1 ignoring T2')
chi2=N*trace(B'*B)
%Decompose B to u,d,v
[v d u]=svd(B',0);
%sqrN is the square root of N
sqrN=sqrt(N);
fprintf('Row scores')
sqrN*sqriK*u(:,1)*d(1,1)

%G is the information matrix due to T2 eliminating T1
G=invK*T2;
%E is the "standardized" data matrix due to T2 eliminating T1
E=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T2 eliminating T1')
chi3=N*trace(E'*E)
%Decompose E to u,d,v
[v d u]=svd(E',0);
fprintf('Row scores')
sqrN*sqriK*u(:,1)*d(1,1)
fprintf('Total chi-square (sum of chi2 and chi3)')
chi2+chi3
Chi1

%G is the information matrix due to T1 eliminating T2
G=invK*T1;
%E is the "standardized" data matrix due to T1 eliminating T2
E=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T1 eliminating T2')
chi3=N*trace(E'*E)
%Decompose E to u,d,v
[v d u]=svd(E',0);
fprintf('Row scores')
sqrN*sqriK*u(:,1)*d(1,1)

%G is the information matrix due to T2 ignoring T1
G=Q*T2;
%B is the "standardized" data matrix due to T2 ignoring T1
B=sqrK*G*inv(G'*K*G)*G'*F*sqriL;
fprintf('Chi-square for T2 ignoring T1')
chi2=N*trace(B'*B)
%Decompose B to u,d,v
[v d u]=svd(B',0);
fprintf('Row scores')
sqrN*sqriK*u(:,1)*d(1,1)

