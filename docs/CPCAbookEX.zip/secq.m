function mdl=secq(ir,ibk,mdl,nr)
i=1;
while i<nr,
j=ibk(i);
if j>1,
s=0.0;
for k=1:j
s=s+mdl(ir(i+k-1));
end %k
s=s/j;
for k=1:j
mdl(ir(i+k-1))=s;
end %k
end %if
i=i+j;
end %while

