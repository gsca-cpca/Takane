%An improved method for GSCA
load rectangle.txt
rect=rectangle;
%z=[kron(eye(10),ones(10,1)), kron(ones(10,1),eye(10)), rect(:,1), rect(:,3), rect(:,5), rect(:,7)];
%z=[kron(eye(10),ones(10,1)), kron(ones(10,1),eye(10)), rect(:,2), rect(:,4), rect(:,6), rect(:,8)];
z=[kron(eye(10),ones(10,1)), kron(ones(10,1),eye(10)), rect(:,1)+rect(:,2), rect(:,3)+rect(:,4), rect(:,5)+rect(:,6), rect(:,7)+rect(:,8)];
[N n]=size(z);
Ns=[100];
Ng=1;
Nb(1)=1;
Ne(1)=Ns(1);
if Ng >= 2
for i=2:Ng
    i1=i-1;
    Nb(i)=Ne(i1)+1;
    Ne(i)=Ne(i1)+Ns(i);
end
end
N=Ne(Ng);
nv=[10 10 4];
K=3;
nb(1)=1;
ne(1)=nv(1);
for i=2:K
i1=i-1;
nb(i)=ne(i1)+1;
ne(i)=ne(i1)+nv(i);
end

%Standardize the data
X=zeros(N,n);
R=zeros(n*Ng,n);
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
fm=sum(z(Nbb:Nee,:))/Ns(g);
Y=z(Nbb:Nee,:)-ones(Ns(g),1)*fm;
X(Nbb:Nee,:)=Y;
sd(1:4)=sqrt(diag(Y(:,21:n)'*Y(:,21:n)/Ns(g)));
X(Nbb:Nee,21:n)=Y(:,21:n)*inv(diag(sd(1:4)));
R(n*(g-1)+1:n*g,:)=X(Nbb:Nee,:)'*X(Nbb:Nee,:);
end
X1=X;

%Prepare for data transformations;
dt=1;
if dt==1
    vb=[21 22 23 24];
    nm=length(vb);
    Y=zeros(N,nm);
    YY=Y;
    Xp=Y;
    z1=Y;
    ir=zeros(N,nm);
    ibk=zeros(N,nm);
    ps=0;
    for i=1:nm
        m=vb(i);
        for g=1:Ng
            Nbb=Nb(g);
            Nee=Ne(g);
            [z1(Nbb:Nee,i) ir(Nbb:Nee,i)]=sort(z(Nbb:Nee,m));
            ibk(Nbb:Nee,i)=block1(X(Nbb:Nee,m),ir(Nbb:Nee,i),Ns(g));
        end %g
    end %i
end %if dt==1
    
%Initial estimates
c=zeros(2*nv(3),Ng);
ce=c;
cn=c;
w=zeros(ne(2),Ng);
wu=w;
wn=w;
U=zeros(N,2);
for g=1:Ng
sqrN(g)=sqrt(Ns(g));
end

F2=0;
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    ng1=n*(g-1);
for i=1:2
    nbb=nb(i);
    nee=ne(i);
    Xi=X(Nbb:Nee,nbb:nee);
    Ri=R(ng1+nbb:ng1+nee,nbb:nee);
    [u0 d0 v0]=svd(Ri);
    d00=sqrt(d0(1,1));
    w(nbb:nee,g)=sqrN(g)*v0(:,1)/d00;
    U(Nbb:Nee,i)=Xi*w(nbb:nee,g);
end
cc=pinv(U'*U)*U'*X(Nbb:Nee,nb(3):ne(3));
for i=1:2
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    c(nq1:nq,g)=cc(i,:)';
end
end
w'
ce=c;
ce'
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    Xi=X(Nbb:Nee,nb(3):ne(3));
    Ei=Xi-U(Nbb:Nee,:)*cc;
    F2=F2+trace(Ei'*Ei);
end
F0=1-F2/(N*nv(3))

%Iteration starts here
nb1=nb(1);
ne1=ne(1);
nb2=nb(2);
ne2=ne(2);
nb3=nb(3);
ne3=ne(3);
nn=ne(2);
C=zeros(Ng*nn,nn);
y=zeros(nn,Ng);

lp=0;
dif=1;
while dif>.00000000001 & lp<100
    lp=lp+1;
%W estimation phase
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    ng1=nn*(g-1);
c1=ce(1:nv(3),g);
c2=ce(nv(3)+1:2*nv(3),g);
C(ng1+nb1:ng1+ne1,nb1:ne1)=(c1'*c1)*R(ng1+nb1:ng1+ne1,nb1:ne1);
C(ng1+nb2:ng1+ne2,nb1:ne1)=(c1'*c2)*R(ng1+nb2:ng1+ne2,nb1:ne1);
C(ng1+nb1:ng1+ne1,nb2:ne2)=C(ng1+nb2:ng1+ne2,nb1:ne1)';
C(ng1+nb2:ng1+ne2,nb2:ne2)=(c2'*c2)*R(ng1+nb2:ng1+ne2,nb2:ne2);
for i=1:2
    nbb=nb(i);
    nee=ne(i);
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    y(nbb:nee,g)=R(ng1+nbb:ng1+nee,nb(3):ne(3))*ce(nq1:nq,g);
end
wu(:,g)=pinv(C(ng1+1:ng1+nn,:))*y;
%Normalize wu
for i=1:2
    s=0;
    nbb=nb(i);
    nee=ne(i);
    u=X(Nbb:Nee,nbb:nee)*wu(nbb:nee,g);
    s=1/sqrt(u'*u/Ns(g));
    wn(nbb:nee,g)=s*wu(nbb:nee,g);
    U(Nbb:Nee,i)=s*u;
end
end
w=wn;

%C estimation phase
F2=0;
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    UU=U(Nbb:Nee,:);
    nbb=nb(3);
    nee=ne(3);
    cnn=pinv(UU'*UU)*UU'*X(Nbb:Nee,nbb:nee);
    Ei=X(Nbb:Nee,nbb:nee)-UU(Nbb:Nee,:)*cnn;
    F2=F2+trace(Ei'*Ei);
    for i=1:2
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    cn(nq1:nq,g)=cnn(i,:)';
    end
end
F=1-F2/(N*nv(3));
ce=cn;
dif=F-F0;
[lp F0 F dif]
F0=F;

%Data tranformations
if dt==1
    for g=1:Ng
        Nbb=Nb(g);
        Nee=Ne(g);
        A=[-w(1:10,g) zeros(10,5);
            zeros(10,1) -w(11:20,g) zeros(10,4);
            zeros(4,2) eye(4)];
        CC=[ce(1:nv(3),g)';
            ce(nv(3)+1:2*nv(3),g)';
            eye(4)];
        B=A*CC;
        for i=1:nm
            m=vb(i);
            B0=B;
            B0(m,:)=zeros(1,nv(3));
            bm=B(m,:)';
            bmm=bm'*bm;
            Y(Nbb:Nee,i)=-X(Nbb:Nee,:)*B0*bm/bmm;
            YY(Nbb:Nee,i)=Y(Nbb:Nee,i);
            zs=zeros(Ns(g),1);
            sqrbmm=sqrt(bmm);
            Y(Nbb:Nee,i)=Y(Nbb:Nee,i)*sqrbmm;
            if ps==1
                Y(Nbb:Nee,i)=secq(ir(Nbb:Nee,i),ibk(Nbb:Nee,i),Y(Nbb:Nee,i),Ns(g));
            else
                ir(Nbb:Nee,i)=prm(ir(Nbb:Nee,i),ibk(Nbb:Nee,i),Y(Nbb:Nee,i),Ns(g));
            end
            zs=tr(1,Y(Nbb:Nee,i),ir(Nbb:Nee,i),Ns(g));
            X(Nbb:Nee,m)=zs/sqrbmm;
            Xp(Nbb:Nee,i)=X(Nbb:Nee,m);
        end %i
        for i=1:nm
            m=vb(i);
            s=1/sqrt(X(Nbb:Nee,m)'*X(Nbb:Nee,m)/Ns(g));
            X(Nbb:Nee,m)=s*X(Nbb:Nee,m);
        end
        R(n*(g-1)+1:n*g,:)=X(Nbb:Nee,:)'*X(Nbb:Nee,:);
    end %g
end %if dt==1

end %while

w'
ce'

if dt==1
    aa=0;
    for i=1:nm
        %i=1
        m=vb(i);
        for g=1:Ng
            aa=aa+1;
            Nbb=Nb(g);
            Nee=Ne(g);
            %a=Ng*(i-1)+g;
            figure(fix((aa-1)/4)+1)
            subplot(2,2,aa-fix((aa-1)/4)*4)
            plot(z(Nbb:Nee,m),YY(Nbb:Nee,i),'b.')
            xlabel('observed data')
            ylabel('transformed data')
            axis('square')
            hold on
            xp1=zeros(Ns(g),1);
            for j=Nbb:Nee
                xp1(j)=Xp(ir(j,i)+Nb(g)-1,i);
            end
            plot(z1(Nbb:Nee,i),xp1(Nbb:Nee))
            axis([-1 1.1*max(z(Nbb:Nee,m)) -3 3])
            title(['Variable ' int2str(i) ' Group ' int2str(g)])
            hold off
        end
    end
end

%Bootstrap reliability assessment
X0=X1;
w0=w;
ce0=ce;
F00=F0;

fw=zeros(nn,Ng);
vw=zeros(nn,Ng);
pw=zeros(nn,Ng);
fce=zeros(2*nv(3),Ng);
vce=zeros(2*nv(3),Ng);
pce=zeros(2*nv(3),Ng);
fF=0;
vF=0;

NN=100;
zz=zeros(N,n);
for j=1:NN
%    j=1;
    for g=1:Ng
        Nbb=Nb(g);
        Nee=Ne(g);
    id=fix(rand(Ns(g),1)*Ns(g)+1)+(Nbb-1)*ones(Ns(g),1);
    for i=Nbb:Nee
        zz(i,:)=X0(id(i-Nbb+1),:);
    end
    end
    
%Standardize the data
X=zeros(N,n);
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
fm=sum(zz(Nbb:Nee,:))/Ns(g);
Y=zz(Nbb:Nee,:)-ones(Ns(g),1)*fm;
X(Nbb:Nee,:)=Y;
sd(1:4)=sqrt(diag(Y(:,21:n)'*Y(:,21:n))/Ns(g));
X(Nbb:Nee,21:n)=Y(:,21:n)*inv(diag(sd(1:4)));
R(n*(g-1)+1:n*g,:)=X(Nbb:Nee,:)'*X(Nbb:Nee,:);
end

%Prepare for data transformations;
if dt==1
    vb=[21 22 23 24];
    nm=length(vb);
    Y=zeros(N,nm);
    YY=Y;
    Xp=Y;
    z1=Y;
    ir=zeros(N,nm);
    ibk=zeros(N,nm);
    for i=1:nm
        m=vb(i);
        for g=1:Ng
            Nbb=Nb(g);
            Nee=Ne(g);
            [z1(Nbb:Nee,i) ir(Nbb:Nee,i)]=sort(zz(Nbb:Nee,m));
            ibk(Nbb:Nee,i)=block1(X(Nbb:Nee,m),ir(Nbb:Nee,i),Ns(g));
        end %g
    end %i
end %if dt==1

%Initial estimates
c=zeros(2*nv(3),Ng);
w=zeros(ne(2),Ng);
wu=w;
wn=w;
U=zeros(N,2);
for g=1:Ng
sqrN(g)=sqrt(Ns(g));
end

F2=0;
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    ng1=n*(g-1);
for i=1:2
    nbb=nb(i);
    nee=ne(i);
    Xi=X(Nbb:Nee,nbb:nee);
    Ri=R(ng1+nbb:ng1+nee,nbb:nee);
    [u0 d0 v0]=svd(Ri);
    d00=sqrt(d0(1,1));
    w(nbb:nee,g)=sqrN(g)*v0(:,1)/d00;
    U(Nbb:Nee,i)=Xi*w(nbb:nee,g);
end
cc=pinv(U'*U)*U'*X(Nbb:Nee,nb(3):ne(3));
for i=1:2
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    c(nq1:nq,g)=cc(i,:)';
end
end
w';
ce=c;
ce';
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    Xi=X(Nbb:Nee,nb(3):ne(3));
    Ei=Xi-U(Nbb:Nee,:)*cc;
    F2=F2+trace(Ei'*Ei);
end
F0=1-F2/(N*nv(3));

%Iteration starts here
nb1=nb(1);
ne1=ne(1);
nb2=nb(2);
ne2=ne(2);
nb3=nb(3);
ne3=ne(3);
nn=ne(2);
C=zeros(Ng*nn,nn);
y=zeros(nn,Ng);

lp=0;
dif=1;
while dif>.00000000001 & lp<100
    lp=lp+1;
%W estimation phase
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    ng1=nn*(g-1);
c1=ce(1:nv(3),g);
c2=ce(nv(3)+1:2*nv(3),g);
C(ng1+nb1:ng1+ne1,nb1:ne1)=(c1'*c1)*R(ng1+nb1:ng1+ne1,nb1:ne1);
C(ng1+nb2:ng1+ne2,nb1:ne1)=(c1'*c2)*R(ng1+nb2:ng1+ne2,nb1:ne1);
C(ng1+nb1:ng1+ne1,nb2:ne2)=C(ng1+nb2:ng1+ne2,nb1:ne1)';
C(ng1+nb2:ng1+ne2,nb2:ne2)=(c2'*c2)*R(ng1+nb2:ng1+ne2,nb2:ne2);
for i=1:2
    nbb=nb(i);
    nee=ne(i);
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    y(nbb:nee,g)=R(ng1+nbb:ng1+nee,nb(3):ne(3))*ce(nq1:nq,g);
end
wu(:,g)=pinv(C(ng1+1:ng1+nn,:))*y;
%Normalize wu
for i=1:2
    s=0;
    nbb=nb(i);
    nee=ne(i);
    u=X(Nbb:Nee,nbb:nee)*wu(nbb:nee,g);
    s=1/sqrt(u'*u/Ns(g));
    wn(nbb:nee,g)=s*wu(nbb:nee,g);
    U(Nbb:Nee,i)=s*u;
end
end
w=wn;

%C estimation phase
F2=0;
for g=1:Ng
    Nbb=Nb(g);
    Nee=Ne(g);
    UU=U(Nbb:Nee,:);
    nbb=nb(3);
    nee=ne(3);
    cnn=pinv(UU'*UU)*UU'*X(Nbb:Nee,nbb:nee);
    Ei=X(Nbb:Nee,nbb:nee)-UU(Nbb:Nee,:)*cnn;
    F2=F2+trace(Ei'*Ei);
    for i=1:2
    nq1=(i-1)*nv(3)+1;
    nq=i*nv(3);
    cn(nq1:nq,g)=cnn(i,:)';
    end
end
F=1-F2/(N*nv(3));
ce=cn;
dif=F-F0;
[lp F0 F dif];
F0=F;

%Data tranformations
if dt==1
    for g=1:Ng
        Nbb=Nb(g);
        Nee=Ne(g);
        A=[-w(1:10,g) zeros(10,5);
            zeros(10,1) -w(11:20,g) zeros(10,4);
            zeros(4,2) eye(4)];
        CC=[ce(1:nv(3),g)';
            ce(nv(3)+1:2*nv(3),g)';
            eye(4)];
        B=A*CC;
        for i=1:nm
            m=vb(i);
            B0=B;
            B0(m,:)=zeros(1,nv(3));
            bm=B(m,:)';
            bmm=bm'*bm;
            Y(Nbb:Nee,i)=-X(Nbb:Nee,:)*B0*bm/bmm;
            YY(Nbb:Nee,i)=Y(Nbb:Nee,i);
            zs=zeros(Ns(g),1);
            sqrbmm=sqrt(bmm);
            Y(Nbb:Nee,i)=Y(Nbb:Nee,i)*sqrbmm;
            if ps==1
                Y(Nbb:Nee,i)=secq(ir(Nbb:Nee,i),ibk(Nbb:Nee,i),Y(Nbb:Nee,i),Ns(g));
            else
                ir(Nbb:Nee,i)=prm(ir(Nbb:Nee,i),ibk(Nbb:Nee,i),Y(Nbb:Nee,i),Ns(g));
            end
            zs=tr(1,Y(Nbb:Nee,i),ir(Nbb:Nee,i),Ns(g));
            X(Nbb:Nee,m)=zs/sqrbmm;
            Xp(Nbb:Nee,i)=X(Nbb:Nee,m);
        end %i
        for i=1:nm
            m=vb(i);
            s=1/sqrt(X(Nbb:Nee,m)'*X(Nbb:Nee,m)/Ns(g));
            X(Nbb:Nee,m)=s*X(Nbb:Nee,m);
        end
        R(n*(g-1)+1:n*g,:)=X(Nbb:Nee,:)'*X(Nbb:Nee,:);
    end %g
end %if dt==1

end %while

for g=1:Ng
    for i=1:2
    nbb=nb(i);
    nee=ne(i);
    sn(i)=sign(w0(nbb:nee,g)'*w(nbb:nee,g));
    w(nbb:nee,g)=sn(i)*w(nbb:nee,g);
    ce((i-1)*nv(3)+1:i*nv(3),g)=sn(i)*ce((i-1)*nv(3)+1:i*nv(3),g);
    end %i
end %g

fw=fw+w;
vw=vw+w.*w;
fce=fce+ce;
vce=vce+ce.*ce;
for g=1:Ng
for i=1:nn
    if w0(i,g)>0
        if w(i,g)<0
            pw(i,g)=pw(i,g)+1;
        end
    else
        if w(i,g)>0
            pw(i,g)=pw(i,g)+1;
        end
    end
end %i
for i=1:2*nv(3)
    if ce0(i,g)>0
        if ce(i,g)<0
            pce(i,g)=pce(i,g)+1;
        end
    else
        if ce(i,g)>0
            pce(i,g)=pce(i,g)+1;
        end
    end
end %i
end %g
fF=fF+F;
vF=vF+F*F;

end %j
fw=fw/NN;
vw=sqrt(vw/NN-fw.*fw);
pw=pw/NN;
fce=fce/NN;
vce=sqrt(vce/NN-fce.*fce);
pce=pce/NN;
[w0 fw vw pw]
[ce0 fce vce pce]
fF=fF/NN;
vF=sqrt(vF/NN-fF*fF);
[F00 fF vF]