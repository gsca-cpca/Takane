function ir=prm(ir,ibk,mdl,nr)
i=1;
while i<nr,
j=ibk(i);
if j>1,
w=zeros(j,1);
iw=zeros(j,1);
id=zeros(j,1);
for k=1:j
id(k)=ir(i+k-1);
w(k)=mdl(id(k));
end %k
[w,iw]=sort(w);
for k=1:j
kk=iw(k);
ir(i+k-1)=id(kk);
end %k
end %if j
i=i+j;
end %while

