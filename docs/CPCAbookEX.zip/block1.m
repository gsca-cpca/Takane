function ibk=block1(z,ir,nr)
ibk=zeros(nr,1);
i=1;
ii=i+1;
ibk(nr)=1;
while i<nr,
id=1;
cont=1;
while cont==1,
if z(ir(i))==z(ir(ii)),
id=id+1;
ii=ii+1;
else
cont=0;
end %if
if ii>nr
cont=0;
end %ii
end %while
i1=ii-1;
for j=i:i1
ibk(j)=id;
end %j
i=ii;
ii=i+1;
end %while i
