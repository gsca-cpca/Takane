%Regularized Multiple-Set Canonical Correlation Analysis (CANO)
%Sorting data (Have words)
load haveword.txt;
K=10;
ict=haveword';
nv=max(ict)';
nb(1)=1;
ne(1)=nv(1);
for i=2:K
i1=i-1;
nb(i)=ne(i1)+1;
ne(i)=ne(i1)+nv(i);
end
[N nt]=size(ict);

%Create a matrix of dummy variables
n=ne(K);
z=zeros(N,n);
for j=1:N
    for i=1:K
        z(j,nb(i)+ict(j,i)-1)=1;
    end
end
Dw=eye(N);
w=diag(Dw);
Nt=sum(w);
cw(1)=w(1);
for i=2:N
    cw(i)=cw(i-1)+w(i);
end
Y=z;
[N n]=size(Y);

%Sample a subset of data if desired
ntl=0;
if ntl==1
    ww=zeros(N,1);
    Ntt=15;
    id=fix(rand(Ntt,1)*Nt+1);
for j=1:Ntt
    i=1;
    while cw(i) < id(j)
        i=i+1;
    end
    ww(i)=ww(i)+1;
end
Dw=diag(ww);
Nt=Ntt;
end

DD=zeros(nt,nt);
for i=1:K
    DD(nb(i):ne(i),nb(i):ne(i))=z(:,nb(i):ne(i))'*Dw*z(:,nb(i):ne(i));
end

%Center the data columnwise
fm=sum(Dw*Y)/Nt;
X=Y-ones(N,1)*fm;
XXi=pinv(X*X');


ip=2; %if rank(Xi^{-j})=pi for all i and j
%ip=2; %if rank(Xi^{-j})\neq pi for some i and j, but rank(Xi^{-j})=rank(Xi) for all i and j
%ip=3; %if rank(Xi^{-j})\neq pi for some i and j, and rank(Xi^{-j})\neq rank(Xi) for some i and j
%if ip=0, the appropriate value of ip should be determined here

XX=X'*Dw*X;
    rt=zeros(n,n);
    for i=1:K
        di=XX(nb(i):ne(i),nb(i):ne(i));
        [u9 d9 v9]=svd(di);
        r=rank(di);
        dii=u9(:,1:r)*pinv(d9(1:r,1:r))*v9(:,1:r)';
        rt(nb(i):ne(i),nb(i):ne(i))=di*dii;
    end
Xtt=zeros(Nt,n);
nc=0;
for j=1:N
    nw=Dw(j,j);
    if nw>0
    for i=1:nw
        nc=nc+1;
        Xtt(nc,:)=X(j,:);
    end
    end
end
Xti=pinv(Xtt*Xtt');

%Permutation Test for Dimensionality Selection
nbs=100;
ldam=[0 .1 1 2 5 10]; %\lambda's
clear pbtab;
rtt=zeros(n,n);

for m=1:length(ldam)
Xt=Xtt;
lda=ldam(m); 
Mlda=eye(Nt)+lda*Xti;
Dj=zeros(n,n);
XXt=Xt'*Xt+lda*rt;
for i=1:K
    Dji=XXt(nb(i):ne(i),nb(i):ne(i));
    [ut dt vt]=svd(Dji);
    r=rank(Dji);
    Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(pinv(dt(1:r,1:r)))*vt(:,1:r)';
end
B0=Dj*XXt*Dj;
[u0 d0 v0]=svd(B0);
V0=Dj*v0;
U0=Xt*V0*inv(sqrt(d0));

pbt=0;
ls=0;
while pbt<.05 & ls < N-1,
    ls=ls+1;
    rmxc=d0(ls,ls);
    fmx=0;
    ibs=0;
    for i=1:K
        dji=Xt(:,nb(i):ne(i))'*Xt(:,nb(i):ne(i));
        [ut dt vt]=svd(dji);
        r=rank(dji);
        dj=ut(:,1:r)*inv(dt(1:r,1:r))*vt(:,1:r)';
        rtt(nb(i):ne(i),nb(i):ne(i))=dj*dji;
    end
    Xp=[Xt(:,nb(1):ne(1)) zeros(Nt,n-nv(1))];
while ibs<nbs,
        ibs=ibs+1;
        for i=2:K
            rp=randperm(Nt);
            nbb=nb(i);
            nee=ne(i);
            for j=1:Nt
                Xp(j,nbb:nee)=Xt(rp(j),nbb:nee);
            end
        end      
        XXplda=Xp'*Xp+lda*rtt;
        B5=Dj*XXplda*Dj;
[u5 d5 v5]=svd(B5);

rmx=d5(ls,ls);
if rmx>rmxc,
    fmx=fmx+1;
end
rmxx(ibs)=rmx;
end %while ibs<nbs
pbt=fmx/nbs;
pbtab(ls,m)=pbt;

%deflation
%Xt=Xt-U0(:,ls)*U0(:,ls)'*Mlda*Xt;
end %while pbt<.05

end %m
pbtab

%Linear K-set CANO
nd=2;
for i=1:K
Dji=DD(nb(i):ne(i),nb(i):ne(i));
[ut dt vt]=svd(Dji);
r=rank(Dji);
Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(inv(dt(1:r,1:r)))*vt(:,1:r)'; %D^{-1/2}
end %i
B1=Dj*XX*Dj; %D^{-1/2}X'XD^{-1/2}
[u1 d1 v1]=svd(B1);
dd1=diag(d1);
dd1(1:5)'
V1=Dj*v1(:,1:nd); %W*
sqrd1=sqrt(d1(1:nd,1:nd));
W1=V1*sqrd1; %W_i to calculate F_i = X_iW_i
U1=X*V1*inv(sqrd1); %F = XW*\Delta^{-1}
sqrNt=sqrt(Nt);
A1=sqrNt*W1;
F1=sqrNt*U1;
sse=0;
for i=1:K
Xi=X(:,nb(i):ne(i));    
Ui=Xi*W1(nb(i):ne(i),:);
Res=U1-Ui;
sse=sse+trace(Res'*Dw*Res);
end
[A1 X'*U1/sqrNt]
sse=sse/K

ccr=diag(sqrt((dd1(1:nd)-ones(nd,1))/(K-1)));

%Leave One Out Method
nd=2;
Nt1=Nt-1;
sqrNt1=sqrt(Nt1);
rtt=zeros(n,n);

for m=1:length(ldam)
    
%m=1;
lda=ldam(m);

XXlda=XX+lda*rt;
for i=1:K
    Dji=XXlda(nb(i):ne(i),nb(i):ne(i));
    [ut dt vt]=svd(Dji);
    r=rank(Dji);
    Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(inv(dt(1:r,1:r)))*vt(:,1:r)';
end
B0=Dj*XXlda*Dj;
[u0 d0 v0]=svd(B0);
V0=Dj*v0(:,1:nd);
W0=V0*sqrt(d0(1:nd,1:nd));

lda1=lda*Nt1/Nt;

U2=zeros(N,nd);
U2i=zeros(N,nd*K);
for j=1:N
%    if ip==3
%    rt matrix has to be created for each j
%    end
    XXjj=XX-X(j,:)'*X(j,:);
    for i=1:K
        dji=XXjj(nb(i):ne(i),nb(i):ne(i));
        [us ds vs]=svd(dji);
        r=rank(dji);
        dj=us(:,1:r)*inv(ds(1:r,1:r))*vs(:,1:r)';
        rtt(nb(i):ne(i),nb(i):ne(i))=dji*dj;
    end
    XXj=XXjj+lda1*rtt; % X^{-j}'X^{-j} + \lambda I
    for i=1:K
        Dji=XXj(nb(i):ne(i),nb(i):ne(i));
        [ut dt vt]=svd(Dji);
        r=rank(Dji);
        Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(inv(dt(1:r,1:r)))*vt(:,1:r)';
        %D(\lambda)^{-1/2}
    end %i
    B2=Dj*XXj*Dj; %D(\lambda)^{-1/2}(X^{-j}'X^{-j} + \lambda I)D(\lambda)^{-1/2}
    [u2 d2 v2]=svd(B2);
    V2=Dj*v2; %W*
    sqrd2=sqrt(d2);
    W2t=V2*sqrd2; %W_i to calculate F_i = X_iW_i
    a=W2t'*W0;
    [u10 d10 v10]=svd(a,0);
    T=u10*v10';
    W2=W2t*T;
    U2(j,:)=X(j,:)*V2*inv(sqrd2)*T; %f_j'
    for i=1:K
        i1=(i-1)*nd+1;
        i2=i*nd;
        U2i(j,i1:i2)=X(j,nb(i):ne(i))*W2(nb(i):ne(i),:); %f_{ij}'
    end %i
end %j

U2=U2-ones(N,1)*sum(Dw*U2)/Nt;
sc=sqrt(inv(diag(diag(U2'*Dw*U2))))*ccr;
sse1=0;
for i=1:K
    i1=(i-1)*nd+1;
    i2=i*nd;
    U2ii=U2i(:,i1:i2);
    Res1=(U2-U2ii)*sc;
    sse1=sse1+trace(Res1'*Dw*Res1);
end %i
sse11(m)=sse1/K;
%sc
[lda sse11(m)]

end %m

%Regularized K-set CANO
mm=find(sse11==min(sse11));
lda=ldam(mm);
lda=1;
Mlda=eye(N)+lda*pinv(Dw)*XXi;
if ip==3,
%matrix rt has to be constructed when ip=3    
end
XXlda=XX+lda*rt;
for i=1:K
    Dji=XXlda(nb(i):ne(i),nb(i):ne(i));
    [ut dt vt]=svd(Dji);
    r=rank(Dji);
    Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(inv(dt(1:r,1:r)))*vt(:,1:r)';
end
B3=Dj*XXlda*Dj;
[u3 d3 v3]=svd(B3);
V3=Dj*v3(:,1:nd);
sqrd3=sqrt(d3(1:nd,1:nd));
W3=V3*sqrd3;
U3=X*V3*inv(sqrd3);
A3=sqrNt*W3;
[A3 X'*U3/sqrNt]
F3=sqrNt*U3;

sse3=0;
for i=1:K
    Ui=X(:,nb(i):ne(i))*W3(nb(i):ne(i),:);
    Res3=U3-Ui;
    sse3=sse3+trace(Res3'*Dw*Mlda*Res3);
end
sse3=sse3/K

%Bootstrap Confidence Regions
for k=1:2
    if k==1,
        lda=0;
    else
        lda=ldam(mm);
    end
    FW=zeros(n,nd);
    VW=zeros(n,nd);
    PW=zeros(n,nd);
    CW=zeros(n,nd*(nd+1)/2);
    FU=zeros(N,nd);
    VU=zeros(N,nd);
    CU=zeros(N,nd*(nd+1)/2);
    fsse=0;
    vsse=0;
    %
    NN=1000;
    %
for j=1:NN
%Resample the data    
    ww=zeros(N,1);
    id=fix(rand(Nt,1)*Nt+1);
    for j=1:Nt
    i=1;
    while cw(i) < id(j)
        i=i+1;
    end
    ww(i)=ww(i)+1;
    end
    Dww=diag(ww);
       
%Center the resampled data
fm=sum(Dww*X)/Nt;
Xb=X-ones(N,1)*fm;
M=Dww+lda*pinv(Xb*Xb');

XXb=Xb'*Dww*Xb;
%Reconstruct rt and D(\lambda)^{-1/2}
if k==2
    rt=zeros(n,n);
    for i=1:K
        di=XXb(nb(i):ne(i),nb(i):ne(i));
        [u9 d9 v9]=svd(di);
        r=rank(di);
        dii=u9(:,1:r)*pinv(d9(1:r,1:r))*v9(:,1:r)';
        rt(nb(i):ne(i),nb(i):ne(i))=di*dii;
    end
end
XXblda=XXb+lda*rt;
for i=1:K
    Dji=XXblda(nb(i):ne(i),nb(i):ne(i));
    [ut dt vt]=svd(Dji);
    r=rank(Dji);
    Dj(nb(i):ne(i),nb(i):ne(i))=ut(:,1:r)*sqrt(pinv(dt(1:r,1:r)))*vt(:,1:r)';
end
B4=Dj*XXblda*Dj;
[u4 d4 v4]=svd(B4);
V4=Dj*v4;
sqrd4=sqrt(d4);
W4t=V4*sqrd4;
if k==1
a=W4t'*W1;
else
a=W4t'*W3;
end
[u10 d10 v10]=svd(a,0);
T=u10*v10';
W4=W4t*T;
U4=Xb*V4*pinv(sqrd4)*T;
sse4=0;
for i=1:K
    Uib=Xb(:,nb(i):ne(i))*W4(nb(i):ne(i),:);
    Res4=U4-Uib;
    sse4=sse4+trace(Res4'*M*Res4);
end
sse4=sse4/K;
fsse=fsse+sse4;
vsse=vsse+sse4*sse4;
FW=FW+W4;
VW=VW+W4.*W4;
if nd==2
for ii=1:n
    CW(ii,2)=CW(ii,2)+W4(ii,1)*W4(ii,2);
end
end
Ut=X*V4*pinv(sqrd4)*T;
FU=FU+Ut;
VU=VU+Ut.*Ut;
if nd==2
    for ii=1:N
        CU(ii,2)=CU(ii,2)+Ut(ii,1)*Ut(ii,2);
    end
end

if k==1
    for i=1:n
        for kk=1:nd
            if W1(i,kk)>0
                if W4(i,kk)<0
                    PW(i,kk)=PW(i,kk)+1;
                end
            else
                if W4(i,kk)>0
                    PW(i,kk)=PW(i,kk)+1;
                end
            end
        end
    end
else
    for i=1:n
        for kk=1:nd
            if W3(i,kk)>0
                if W4(i,kk)<0
                    PW(i,kk)=PW(i,kk)+1;
                end
            else
                if W4(i,kk)>0
                    PW(i,kk)=PW(i,kk)+1;
                end
            end
        end
    end
end  

end %j
fsse=fsse/NN;
vsse=sqrt(vsse/NN-fsse*fsse);
FW=FW/NN;
VW=VW/NN-FW.*FW;
PW=PW/NN;
if nd==2
for ii=1:n
    CW(ii,2)=CW(ii,2)/NN-FW(ii,1)*FW(ii,2);
    CW(ii,1)=VW(ii,1);
    CW(ii,3)=VW(ii,2);
end
end
ms=VW;
VW=sqrt(VW);
[fsse vsse]
NFW=sqrNt*FW;
NVW=sqrNt*VW;
if k==1
[A1 PW NFW A1-NFW NVW]
else
[A3 PW NFW A3-NFW NVW]
end
FU=FU/NN;
VU=VU/NN-FU.*FU;
if nd==2
    for ii=1:N
        CU(ii,2)=CU(ii,2)/NN-FU(ii,1)*FU(ii,2);
        CU(ii,1)=VU(ii,1);
        CU(ii,3)=VU(ii,2);
    end
end
NFU=sqrNt*FU;
VU=sqrt(VU);
NVU=sqrNt*VU;
NCU=Nt*CU;
if k==1
    [F1 NFU F1-NFU NVU]
else
    [F3 NFU F3-NFU NVU]
end

%Draw Confidence Region
if nd==2
    NFU1=NFU;
    NCU1=NCU;
    if k==2
        NFU1=1.15*NFU;
        NFU1(:,2)=-NFU1(:,2);
        NCU1=1.15*1.15*NCU;
        NCU1(:,2)=-NCU1(:,2);
    end
    lbls=[' 1';' 2';' 3'; ' 4'; ' 5';' 6';' 7';' 8';' 9';'10';'11';'12';'13';'14';'15';'16';'17';'18';'19';'20';'21';'22';'23';'24';'25';'26';'27';'28';'29'];
    figure(k)
    plot(NFU1(:,1),NFU1(:,2),'.k')
    text(NFU1(:,1),NFU1(:,2),lbls)
    axis('square')
    axis([-3 4 -4 3])
    title('95% Confidence Regions of the Subject Points')
    hold on
    for ii=1:N
        dm=cellip(NCU1(ii,:),NFU1(ii,:));
    end
    hold off;
end
if k==1
bs=W1-FW;
else
bs=W3-FW;
end

Em(k,1)=sum(sum(ms));
Em(k,2)=trace(bs'*bs)';
Em(k,3)=Em(k,1)+Em(k,2);

end %k

