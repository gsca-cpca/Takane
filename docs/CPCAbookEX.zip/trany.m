function mdl=trany(tmdl,tform,nr)
mdl=zeros(nr,1);
mdl(1)=tmdl(1);
for i=2:nr
im1=i-1;
if tmdl(i)>=mdl(im1),
mdl(i)=tmdl(i);
else
s=tmdl(i);
fn=1;
j=0;
cont=1;
while cont==1,
j=j+1;
imj=i-j;
s=s+tform*tmdl(imj);
fn=fn+tform;
mdl(imj)=s/fn;
if j==im1,
cont=0;
elseif mdl(imj)>=tmdl(imj-1),
cont=0;
end
end %while
l=imj+1;
for j=l:i
jm1=j-1;
mdl(j)=0;
for m=imj:i
if m==jm1,
mdl(j)=mdl(j)+tmdl(m);
else
mdl(j)=mdl(j)+tform*tmdl(m);
end %if
end %m
mdl(j)=mdl(j)/fn;
end %j
for j=imj:i
tmdl(j)=mdl(j);
end %j
end %if tmdl(im1)>=mdl(i)
end %i

