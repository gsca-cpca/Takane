%Symmetric CA qnd CCA
F=[49 46 115;
    293 140 277;
    244 66 100;
    27 34 117;
    134 98 167;
    138 38 73;
    25 40 88;
    172 103 312;
    93 57 135];
K=diag(sum(F'));
Kinv=inv(K);
Ksq=sqrt(K);
Ki2=inv(Ksq);
N=sum(diag(K));
sqrtN=sqrt(N);
e=ones(9,1);
Q=eye(9)-e*inv(e'*K*e)*e'*K;
L=diag(sum(F));
Linv=inv(L);
Lsq=sqrt(L);
Li2=inv(sqrt(L));
A=Ki2*Q'*F*Li2;
ChiA=N*trace(A'*A)
[u d v]=svd(A,0);
U=sqrtN*Ki2*u(:,1)
V=sqrtN*Li2*v(:,1)*d(1,1)
d(1,1)^2
N*d(1,1)^2/ChiA*100

%Define T1
T1=[1 0 1 1;
    0 0 1 1;
    -1 0 1 1;
    1 0 -1 1;
    0 0 -1 1;
    -1 0 -1 1;
    0 1 0 -2;
    0 0 0 -2;
    0 -1 0 -2];
%T1 ignoring T2
X=Q*T1;
B=Ksq*X*inv(X'*K*X)*X'*F*Li2;
ChiB=N*trace(B'*B)
[u1 d1 v1]=svd(B,0);
U=sqrtN*Ki2*u1(:,1)
V=sqrtN*Li2*v1(:,1)*d1(1,1)
d1(1,1)^2
N*d1(1,1)^2/ChiA*100
ChiB/ChiA*100

%T1 eliminating T2
XX=Kinv*T1;
E=Ksq*XX*inv(XX'*K*XX)*XX'*F*Li2;
ChiE=N*trace(E'*E);
[u2 d2 v2]=svd(E,0);
U=sqrtN*Ki2*u2(:,1);
V=sqrtN*Li2*v2(:,1)*d2(1,1);
d2(1,1)^2
N*d2(1,1)^2/ChiA*100
ChiE/ChiA*100

%%%%%%%%%%%%%%%%%%%%%%%%%%

%Define T2
T2=[1 0 0 1;
    -2 0 0 -1;
    1 0 0 0;
    0 1 0 -1;
    0 -2 0 1;
    0 1 0 0;
    0 0 1 0;
    0 0 -2 0;
    0 0 1 0];
%T2 eignoring T1
X=Q*T2;
J=Ksq*X*inv(X'*K*X)*X'*F*Li2;
ChiJ=N*trace(J'*J)
[u3 d3 v3]=svd(J,0);
U=sqrtN*Ki2*u3(:,1);
V=sqrtN*Li2*v3(:,1)*d3(1,1);
d3(1,1)^2
N*d3(1,1)^2/ChiA*100
ChiJ/ChiA*100

%T2 eliminating T1
XX=Kinv*T2;
LL=Ksq*XX*inv(XX'*K*XX)*XX'*F*Li2;
ChiL=N*trace(LL'*LL)
[u4 d4 v4]=svd(LL,0);
U=sqrtN*Ki2*u1(:,1);
V=sqrtN*Li2*v4(:,1)*d4(1,1);
d4(1,1)^2
N*d4(1,1)^2/ChiA*100
ChiL/ChiA*100

%Check additivities
ChiA
ChiB+ChiL
ChiE+ChiJ

%%%%%%%%%%%%%%%%%%%%%%%%

%Incorporating S1
TT1=[-1;0;1];
e=ones(3,1);
QQ=eye(3)-e*inv(e'*L*e)*e'*L;
Y=QQ*TT1;
B=Ki2*F*Y*inv(Y'*L*Y)*Y'*Lsq;
ChiB=N*trace(B'*B)
[u5 d5 v5]=svd(B,0);
U=sqrtN*Ki2*u5(:,1)
V=sqrtN*Li2*v5(:,1)*d5(1,1)
d5(1,1)^2
N*d5(1,1)^2/ChiA*100
ChiB/ChiA*100

%Incorporating both T1 and S1
X=Q*T1;
E=Ksq*X*inv(X'*K*X)*X'*F*Y*inv(Y'*L*Y)*Y'*Lsq;
ChiE=N*trace(E'*E)
[u6 d6 v6]=svd(E,0);
U=sqrtN*Ki2*u6(:,1)
V=sqrtN*Li2*v6(:,1)*d5(1,1)
d6(1,1)^2
N*d6(1,1)^2/ChiA*100
ChiE/ChiA*100


